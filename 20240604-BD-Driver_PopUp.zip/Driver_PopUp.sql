--  [dbo].[Driver_PopUp] 1, '', 1, 10
ALTER PROCEDURE [dbo].[Driver_PopUp]
@IdCompanyBranch INT,
@Search VARCHAR(200),
@PageIndex INT,
@PageSize INT
AS
DECLARE @TotalElements INT = 0
 
SELECT 
@TotalElements = COUNT(1)
FROM Driver dr 
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = dr.IdStatus AND tblm.IdColumn > 0
LEFT JOIN Country co ON co.IdCountry = dr.IdCountry
WHERE NOT EXISTS (SELECT 1 FROM Weighing we 
			WHERE dr.IdDriver = we.InputIdDriver 
				AND we.DeletedFlag = 0
				AND we.IdCompanyBranch = @IdCompanyBranch
			    AND (
            (we.IdStatus < 3 AND we.IdWeighingCycle = 1)
            OR
            (we.IdStatus < 2 AND we.IdWeighingCycle = 2)
            ))
AND(
        dr.Driver LIKE '%' + @Search + '%' OR co.IdCountry LIKE '%' + @Search + '%' OR co.Country LIKE '%' + @Search + '%'
		OR dr.IdNumber LIKE '%' + @Search + '%' OR dr.LicenseNumber LIKE '%' + @Search + '%'  
    )
AND dr.DeletedFlag = 0 AND IdCompanyBranch = @IdCompanyBranch

SELECT 
dr.IdDriver,
dr.Driver,
dr.IdCountry,
co.Country,
dr.IdNumber,
dr.LicenseNumber,
dr.IdStatus, 
tblm.[Description] AS [Status],
@TotalElements AS TotalElements
FROM Driver dr 
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = dr.IdStatus AND tblm.IdColumn > 0
LEFT JOIN Country co ON co.IdCountry = dr.IdCountry
WHERE NOT EXISTS (SELECT 1 FROM Weighing we 
			WHERE dr.IdDriver = we.InputIdDriver 
				AND we.DeletedFlag = 0
				AND we.IdCompanyBranch = @IdCompanyBranch
			    AND (
					(we.IdStatus < 3 AND we.IdWeighingCycle = 1)
					OR
					(we.IdStatus < 2 AND we.IdWeighingCycle = 2)
					)
				)
AND(
        dr.Driver LIKE '%' + @Search + '%' OR co.IdCountry LIKE '%' + @Search + '%' OR co.Country LIKE '%' + @Search + '%'
		OR dr.IdNumber LIKE '%' + @Search + '%' OR dr.LicenseNumber LIKE '%' + @Search + '%'  
    )
AND dr.DeletedFlag = 0 AND IdCompanyBranch = @IdCompanyBranch
ORDER BY dr.IdDriver ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY