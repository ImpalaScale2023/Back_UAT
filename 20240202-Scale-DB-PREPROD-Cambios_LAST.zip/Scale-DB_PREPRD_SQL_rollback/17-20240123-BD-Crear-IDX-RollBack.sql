DROP INDEX IDX_weighing_branch_deleted ON [dbo].[Weighing]

GO

DROP INDEX IDX_weighing_id_vehicle_deleted ON [dbo].[Weighing]

GO

DROP INDEX IDX_weighing_status_cycle ON [dbo].[Weighing]