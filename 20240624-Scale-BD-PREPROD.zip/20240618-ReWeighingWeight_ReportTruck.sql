-- [dbo].[ReWeighingWeight_ReportTruck] 1, 1, 300, '20220214', '20240214'
ALTER PROCEDURE [dbo].[ReWeighingWeight_ReportTruck]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@InitialDate VARCHAR(8),
@FinalDate VARCHAR(8)
AS
SELECT
rw.Pila,
rww.Lot,
CONCAT(ve.TruckNumber, '/', ve.TrailerNumber) AS Plate,
ISNULL(ca.Carrier, '') AS Carrier,
ISNULL(rww.[Sequence], 0) AS [Sequence],
CONCAT(rw.LotFrom, ' - ', rw.LotTo) AS LoteReWeight,
rww.GrossWeight,
rww.TareWeight,
rww.NetWeight,
ISNULL(CONVERT(VARCHAR(10), rww.GrossDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.GrossDate), 108),'') AS GrossDate,
ISNULL(CONVERT(VARCHAR(10), rww.GrossDate, 120),'') AS GrossDateOnly,
ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.GrossDate), 108),'') AS GrossHour,
pr.DescProduct,
qu.[Description] AS Quality,
cl.BusinessName AS Client,
--CONVERT(VARCHAR(10), rww.TareDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, rww.TareDate), 108) AS TareDate,
--DATEDIFF(MINUTE, rww.TareDate, rww.GrossDate) AS TimeDiff,
rww.Obs
FROM ReWeighingWeight rww
INNER JOIN Vehicle ve ON ve.IdCompany = rww.IdCompany AND ve.IdCompanyBranch = rww.IdCompanyBranch AND ve.IdVehicle = rww.IdVehicle
LEFT JOIN Carrier ca ON ca.IdCompany = ve.IdCompany AND ca.IdCompanyBranch = ve.IdCompanyBranch AND ca.IdCarrier = ve.IdCarrier
INNER JOIN ReWeighing rw ON rw.IdCompany = rww.IdCompany AND rw.IdCompanyBranch = rww.IdCompanyBranch 
						AND rw.IdReWeighing = rww.IdReWeighing AND rw.DeletedFlag = 0
INNER JOIN Product pr ON pr.IdCompany = rw.IdCompany AND pr.IdCompanyBranch = rw.IdCompanyBranch AND pr.IdProduct = rw.IdProduct
INNER JOIN Quality qu ON qu.IdCompany = rw.IdCompany AND qu.IdCompanyBranch = rw.IdCompanyBranch AND qu.IdQuality = rw.IdQuality
INNER JOIN Client cl ON cl.IdCompany = rw.IdCompany AND cl.IdCompanyBranch = rw.IdCompanyBranch AND cl.IdClient = rw.IdClient
WHERE rww.IdCompany = @IdCompany
AND rww.IdCompanyBranch = @IdCompanyBranch
AND CONVERT(date, rww.CreatedDate) BETWEEN CONVERT(date, @InitialDate) AND CONVERT(date, @FinalDate)
AND rww.DeletedFlag = 0
ORDER BY rw.IdReWeighing ASC