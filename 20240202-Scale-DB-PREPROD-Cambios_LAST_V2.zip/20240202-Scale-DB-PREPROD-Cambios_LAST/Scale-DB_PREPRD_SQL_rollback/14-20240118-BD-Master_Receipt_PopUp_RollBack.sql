--  [dbo].[UC_MASTER_RECEIPT_FWD_PopUp] 1, ''
ALTER PROCEDURE [dbo].[UC_MASTER_RECEIPT_FWD_PopUp]
@IdCompanyBranch INT,
@Search VARCHAR(200)
AS
DECLARE @WHSE_ID VARCHAR(5)
SELECT @WHSE_ID = CodeCompanyBranch FROM dbo.CompanyBranch WHERE IdCompanyBranch = @IdCompanyBranch

SELECT 
uc.TRKNUM,
uc.TRANID,
uc.TRKNUMWHSE_IDCLIENT_ID, 
uc.TRNTYP,
uc.TRLR_ID, 
uc.TRLR_NUM,
uc.DRIVER_NAM,
uc.DRIVER_LIC_NUM,
uc.CARCOD,
uc.CARNAM,
uc.WHSE_ID, 
uc.INVNUM,
uc.CLIENT_ID,
uc.SUPNUM,
uc.ADRNAM_SUP,
uc.PRTNUM,
uc.RCVSTS, 
uc.INV_ATTR_STR1,
uc.INV_ATTR_STR10,
uc.INV_ATTR_STR11, 
uc.INV_ATTR_STR12, 
uc.UC_TOLERANCE,
uc.UC_CONTAINER_FLG,
uc.STOLOC,
uc.UC_UNLOAD,
uc.VC_INVTYP,
uc.LOTNUM,
uc.SUP_LOTNUM,
uc.TRKREF,
uc.PO_NUM, 
uc.INV_ATTR_STR13,
uc.TRLR_REF--,
--uc.DeletedFlag, 
--uc.CreatedIdCompany,
--uc.CreatedIdUser, 
--uc.CreatedDate, 
--uc.UpdatedIdCompany,
--uc.UpdatedIdUser,
--uc.UpdatedDate
FROM UC_MASTER_RECEIPT_FWD uc 
WHERE NOT EXISTS (SELECT IDINBOUND FROM Weighing we 
			WHERE uc.TRKNUM = we.IDINBOUND AND we.DeletedFlag = 0 
			AND we.IdCompanyBranch = @IdCompanyBranch)
AND(
		(@Search = '')
         OR
		(@Search <> '' AND
		uc.TRKNUM LIKE '%' + @Search + '%' 
		OR uc.TRLR_NUM LIKE '%' + @Search + '%'
		OR uc.LOTNUM LIKE '%' + @Search + '%'
		OR uc.clienT_ID LIKE '%' + @Search + '%'
		OR uc.INV_ATTR_STR1 LIKE '%' + @Search + '%'
		)
    )
AND uc.WHSE_ID = @WHSE_ID
AND uc.DeletedFlag = 0