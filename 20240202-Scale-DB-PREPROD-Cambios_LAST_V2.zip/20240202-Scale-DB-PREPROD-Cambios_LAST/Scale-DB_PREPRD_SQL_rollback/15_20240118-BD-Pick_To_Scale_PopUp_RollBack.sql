-- UC_PICK_TO_SCALE_PopUp 1, ''
ALTER PROCEDURE [dbo].[UC_PICK_TO_SCALE_PopUp]
@IdCompanyBranch INT,
@Search VARCHAR(200)
AS
DECLARE @WHSE_ID VARCHAR(5)
SELECT @WHSE_ID = CodeCompanyBranch FROM CompanyBranch WHERE IdCompanyBranch = @IdCompanyBranch

SELECT 
uc.ORDNUM, 
uc.SEGNAM,
uc.TRNTYP, 
uc.WHSE_ID, 
uc.CLIENT_ID, 
uc.SHIP_ID,
uc.WAVENUM,
uc.PRTNUM,
uc.INV_ATTR_STR1,
uc.QTY,
uc.INV_ATTR_STR5,
uc.STOLOC,
uc.UC_CONVEYOR, 
uc.UC_CONTAINER_FLG,
uc.VC_SAMPLE_CLIENT,
uc.VC_SAMPLE_PROD,
uc.UC_SAMP_PL, 
uc.EXTRL_SRVYR, 
uc.ADNL_TST_REQD,
UPPER(ISNULL(sp.SeaPortName,'')) AS OriginPort,
ISNULL(uc.DestinationPort,'') AS DestinationPort,
ISNULL(uc.Buque,'') AS Buque --,
--uc.DeletedFlag, 
--uc.CreatedIdCompany, 
--uc.CreatedIdUser,
--uc.CreatedDate, 
--uc.UpdatedIdCompany,
--uc.UpdatedIdUser,
--uc.UpdatedDate
FROM UC_PICK_TO_SCALE uc
LEFT JOIN SeaPort sp ON sp.IdSeaPort = uc.OriginIdSeaPort
WHERE 
NOT EXISTS (SELECT SHIP_ID FROM UC_PICK_COMPLETE ucp
					WHERE uc.SHIP_ID = ucp.SHIP_ID AND uc.DeletedFlag = 0)
AND
(
        uc.ORDNUM LIKE '%' + @Search + '%' 
		OR uc.CLIENT_ID LIKE '%' + @Search + '%' 
		OR uc.SEGNAM LIKE '%' + @Search + '%' 
		OR uc.TRNTYP LIKE '%' + @Search + '%' 
		OR uc.WHSE_ID LIKE '%' + @Search + '%' 
		OR uc.shiP_ID LIKE '%' + @Search + '%' 
		OR uc.WAVENUM LIKE '%' + @Search + '%' 
		OR uc.PRTNUM LIKE '%' + @Search + '%' 
		OR uc.INV_ATTR_STR1 LIKE '%' + @Search + '%' 
		OR uc.QTY LIKE '%' + @Search + '%' 
		OR uc.INV_ATTR_STR5 LIKE '%' + @Search + '%' 
		OR uc.STOLOC LIKE '%' + @Search + '%' 
		OR uc.UC_CONVEYOR LIKE '%' + @Search + '%' 
		OR uc.UC_CONTAINER_FLG LIKE '%' + @Search + '%' 
		OR uc.VC_SAMPLE_CLIENT LIKE '%' + @Search + '%' 
		OR uc.VC_SAMPLE_PROD LIKE '%' + @Search + '%' 
		OR uc.UC_SAMP_PL LIKE '%' + @Search + '%' 
		OR uc.EXTRL_SRVYR LIKE '%' + @Search + '%'
		OR uc.adnL_TST_REQD LIKE '%' + @Search + '%'
    )
AND uc.WHSE_ID = @WHSE_ID
AND uc.DeletedFlag = 0