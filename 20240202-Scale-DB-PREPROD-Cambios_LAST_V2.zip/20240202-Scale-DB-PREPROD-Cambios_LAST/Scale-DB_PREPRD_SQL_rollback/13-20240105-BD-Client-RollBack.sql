--EXEC [dbo].[Client_DropDown] 1
ALTER PROCEDURE [dbo].[Client_DropDown]
@IdCompany INT,
@IdCompanyBranch INT
AS
SELECT
IdClient,
ClientNumber,
BusinessName
FROM Client
WHERE IdCompany = @IdCompany
AND IdCompanyBranch = @IdCompanyBranch
AND DeletedFlag = 0 
AND IdStatus = 1
ORDER BY IdClient DESC
