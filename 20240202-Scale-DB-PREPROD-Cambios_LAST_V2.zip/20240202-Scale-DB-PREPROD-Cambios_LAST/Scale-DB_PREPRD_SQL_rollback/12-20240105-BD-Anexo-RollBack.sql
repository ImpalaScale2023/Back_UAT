ALTER TABLE [dbo].[Anexo]
DROP COLUMN FlagDestinatario

GO

ALTER PROCEDURE [dbo].[Anexo_InsertUpdate]
@IdCompany INT,
@IdAnexo INT,
@CodAnexo VARCHAR(20),
@RucAnexo VARCHAR(50),
@IdUbigeo VARCHAR(50),
@IdCompanyBranch INT,
@Direccion VARCHAR(250),
@IdCliente INT,
@IdStatus INT,
@IdCompanyAud INT,
@IdUserAud INT,
@Error varchar(MAX) OUTPUT
AS

BEGIN TRAN
BEGIN TRY
	SET @Error = ''
	IF @IdAnexo = 0
	BEGIN
		SET NOCOUNT ON
		SELECT @IdAnexo = ISNULL(MAX(IdAnexo), 0) + 1 FROM Anexo
		SET NOCOUNT OFF
	
		INSERT INTO Anexo (IdCompany, IdAnexo, CodAnexo, RucAnexo, IdUbigeo, IdCompanyBranch, Direccion,
		IdCliente, IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate)
		VALUES (@IdCompany, @IdAnexo, @CodAnexo, @RucAnexo, @IdUbigeo, @IdCompanyBranch, @Direccion, @IdCliente,
				 @IdStatus, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch))
	END
	ELSE
	BEGIN
		UPDATE Anexo
		SET 
		IdCompany = @IdCompany,
		CodAnexo = @CodAnexo,
		RucAnexo = @RucAnexo,
		IdUbigeo = @IdUbigeo,
		IdCompanyBranch = @IdCompanyBranch,
		Direccion = @Direccion,
		IdCliente = @IdCliente,
		IdStatus = @IdStatus,
		DeletedFlag = 0,
		UpdatedIdCompany = @IdCompanyAud,	
		UpdatedIdUser = @IdUserAud,
		UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
		WHERE IdCompany = @IdCompany 
			AND IdAnexo = @IdAnexo
	END
	
	IF EXISTS(SELECT 1 FROM Anexo WHERE IdCompany = @IdCompany
								AND IdCompanyBranch = @IdCompanyBranch
								AND IdAnexo <> @IdAnexo
								AND IdCliente = @IdCliente
								AND CodAnexo = @CodAnexo
								AND RucAnexo = @RucAnexo
								AND IdStatus = 1 
								AND DeletedFlag = 0)
    BEGIN   
		ROLLBACK TRAN
        SET @Error = '#VALID!' + 'This register already exists'
    END
    ELSE
    BEGIN
        COMMIT TRAN
    END
END TRY
BEGIN CATCH
    ROLLBACK TRAN
    SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH

GO

-- EXEC dbo.Anexo_List 1, 0, -300, 1, '', 1, 14
ALTER PROCEDURE [dbo].[Anexo_List]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@IdStatus INT,
@Search VARCHAR(50),
@PageIndex INT,
@PageSize INT
AS

SET NOCOUNT ON
DECLARE @TotalElements INT

DECLARE @Base AS TABLE
(IdFila INT IDENTITY PRIMARY KEY,
IdCompany INT NOT NULL,
IdAnexo INT NOT NULL,
DeletedFlag BIT NOT NULL,
CodAnexo VARCHAR(20) NOT NULL,
RucAnexo VARCHAR(32) NOT NULL,
IdUbigeo VARCHAR(50) NOT NULL,
IdCompanyBranch INT NOT NULL,
CompanyBranch VARCHAR(100) NOT NULL,
Direccion VARCHAR(250)NOT NULL,
IdCliente INT NOT NULL,
RucCliente VARCHAR(32), 
IdStatus INT NOT NULL,
CreatedCompany VARCHAR(100) NOT NULL,
[Status] VARCHAR(500) NOT NULL,
CreatedUser VARCHAR(100) NOT NULL,
CreatedDate VARCHAR(20) NOT NULL,
UpdatedCompany VARCHAR(100),
UpdatedUser VARCHAR(100),
UpdatedDate VARCHAR(20)
)

INSERT INTO @Base (IdCompany, IdAnexo, DeletedFlag, CodAnexo, RucAnexo, IdUbigeo, IdCompanyBranch, CompanyBranch, Direccion,
IdCliente, RucCliente, IdStatus, [Status], CreatedCompany, CreatedUser, CreatedDate, UpdatedCompany,
UpdatedUser, UpdatedDate)
SELECT
an.IdCompany,
an.IdAnexo,
an.DeletedFlag,
an.CodAnexo,
an.RucAnexo,
an.IdUbigeo,
an.IdCompanyBranch,
cb.CodeCompanyBranch AS CompanyBranch,
an.Direccion,
an.IdCliente,
co.Ruc AS RucCliente,
an.IdStatus,
tblm.[Description] AS [Status],
com.CompanyName AS CreatedCompany,
us1.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), an.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), an.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.UpdatedDate), 108), ' ') AS UpdatedDate
FROM Anexo an
LEFT JOIN Client co on co.IdClient = an.IdCliente
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = an.IdStatus AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND an.IdStatus = @IdStatus
AND (an.CodAnexo LIKE '%' + @Search + '%'
	OR cb.CodeCompanyBranch LIKE '%' + @Search + '%'
	OR an.RucAnexo LIKE '%' + @Search + '%'
	OR @Search = ''
)

SELECT @TotalElements = COUNT(1) FROM @Base
SET NOCOUNT OFF

SELECT
IdCompany, IdAnexo, DeletedFlag, CodAnexo, RucAnexo, IdUbigeo, IdCompanyBranch, CompanyBranch, Direccion,
IdCliente, RucCliente, IdStatus, [Status], CreatedCompany, CreatedUser, CreatedDate, UpdatedCompany,
UpdatedUser, UpdatedDate,
@TotalElements AS TotalElements
FROM @Base
ORDER BY IdAnexo ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY