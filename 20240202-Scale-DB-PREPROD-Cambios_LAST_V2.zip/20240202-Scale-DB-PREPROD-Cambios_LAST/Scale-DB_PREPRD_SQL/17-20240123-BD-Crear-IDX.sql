CREATE NONCLUSTERED INDEX IDX_weighing_branch_deleted ON [dbo].[Weighing] (IdCompanyBranch, DeletedFlag) INCLUDE (IDINBOUND)

GO

CREATE INDEX IDX_weighing_id_vehicle_deleted ON [dbo].[Weighing](IdVehicle, DeletedFlag);

GO

CREATE INDEX IDX_weighing_status_cycle ON [dbo].[Weighing](IdStatus, IdWeighingCycle);