INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 50, 0, N'', N'GUIDE ISSUER', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 50, 1, N'', N'Impala', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
INSERT [dbo].[MasterTable] ([IdCompany], [IdTable], [IdColumn], [Valor], [Description], [IdFatherColumn], [IdStatus], [DeletedFlag], [CreatedIdCompany], [CreatedIdUser], [CreatedDate], [UpdatedIdCompany], [UpdatedIdUser], [UpdatedDate]) VALUES (1, 50, 2, N'', N'Cliente', NULL, 1, 0, 1, 1, CAST(N'2023-12-12T11:00:00.000' AS DateTime), NULL, NULL, NULL)
GO
