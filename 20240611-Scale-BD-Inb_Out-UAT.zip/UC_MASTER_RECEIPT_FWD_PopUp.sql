--  [dbo].[UC_MASTER_RECEIPT_FWD_PopUp] 1, '', 1, 10
ALTER PROCEDURE [dbo].[UC_MASTER_RECEIPT_FWD_PopUp]
@IdCompanyBranch INT,
@Search VARCHAR(200),
@PageIndex INT,
@PageSize INT
AS
SET NOCOUNT ON
DECLARE @WHSE_ID VARCHAR(5), @IdCompany INT
SELECT @IdCompany = IdCompany, @WHSE_ID = CodeCompanyBranch FROM dbo.CompanyBranch WHERE IdCompanyBranch = @IdCompanyBranch

--#Weighing
IF OBJECT_ID('tempdb.dbo.#Weighing') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#Weighing;
END
ELSE
BEGIN
	CREATE TABLE dbo.#Weighing(
		[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
		[IdCompany] [int] NOT NULL,
		[IdWeighing] [int] NOT NULL,
		[IDINBOUND] VARCHAR(25) NOT NULL,
		)

	CREATE NONCLUSTERED INDEX [IX_TmpWeighing_IdVehicle] ON dbo.#Weighing
	(
		[IdCompany] ASC,
		[IDINBOUND] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END

INSERT INTO dbo.#Weighing (IdCompany, IdWeighing, IDINBOUND)
SELECT 
we.IdCompany,
we.IdWeighing,
we.IDINBOUND 
FROM dbo.Weighing we 
WHERE we.DeletedFlag = 0
AND we.IdCompanyBranch = @IdCompanyBranch

--#UC_MASTER_RECEIPT_FWD
IF OBJECT_ID('tempdb.dbo.#UC_MASTER_RECEIPT_FWD') IS NOT NULL
BEGIN
  TRUNCATE TABLE dbo.#UC_MASTER_RECEIPT_FWD;
END
ELSE
BEGIN
CREATE TABLE dbo.#UC_MASTER_RECEIPT_FWD(
	[Id] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
	[TRKNUM] VARCHAR(25) NOT NULL
	)
END

INSERT INTO dbo.#UC_MASTER_RECEIPT_FWD
(TRKNUM)
SELECT
uc.TRKNUM
FROM dbo.UC_MASTER_RECEIPT_FWD uc
WHERE NOT EXISTS (SELECT we.IDINBOUND FROM dbo.#Weighing we 
			WHERE @IdCompany = we.IdCompany
				AND uc.TRKNUM = we.IDINBOUND)
AND(
		(@Search = '') OR
		(@Search <> '' AND uc.TRKNUM LIKE '%' + @Search + '%' 
		OR uc.TRLR_NUM LIKE '%' + @Search + '%'
		OR uc.LOTNUM LIKE '%' + @Search + '%'
		OR uc.clienT_ID LIKE '%' + @Search + '%'
		OR uc.INV_ATTR_STR1 LIKE '%' + @Search + '%'
		)
    )
AND uc.WHSE_ID = @WHSE_ID
AND uc.DeletedFlag = 0

ORDER BY uc.CreatedDate ASC
DECLARE @TotalElements INT
SELECT @TotalElements = COUNT(1) FROM dbo.#UC_MASTER_RECEIPT_FWD
SET NOCOUNT OFF

SELECT
mr.TRKNUM, 
mr.TRANID, 
mr.TRKNUMWHSE_IDCLIENT_ID, 
mr.TRNTYP, 
mr.TRLR_ID, 
mr.TRLR_NUM, 
mr.DRIVER_NAM, 
mr.DRIVER_LIC_NUM,
mr.CARCOD, 
mr.CARNAM, 
mr.WHSE_ID, 
mr.INVNUM, 
mr.CLIENT_ID, 
mr.SUPNUM, 
mr.ADRNAM_SUP, 
mr.PRTNUM, 
mr.RCVSTS, 
mr.INV_ATTR_STR1,
mr.INV_ATTR_STR10, 
mr.INV_ATTR_STR11, 
mr.INV_ATTR_STR12, 
mr.UC_TOLERANCE, 
mr.UC_CONTAINER_FLG, 
mr.STOLOC, 
mr.UC_UNLOAD,
mr.VC_INVTYP, 
mr.LOTNUM, 
mr.SUP_LOTNUM, 
mr.TRKREF, 
mr.PO_NUM, 
mr.INV_ATTR_STR13, 
mr.TRLR_REF,
@TotalElements AS TotalElement
FROM dbo.#UC_MASTER_RECEIPT_FWD tmmr
INNER JOIN dbo.UC_MASTER_RECEIPT_FWD mr ON tmmr.TRKNUM = mr.TRKNUM AND mr.DeletedFlag = 0
ORDER BY mr.TRKNUM DESC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY