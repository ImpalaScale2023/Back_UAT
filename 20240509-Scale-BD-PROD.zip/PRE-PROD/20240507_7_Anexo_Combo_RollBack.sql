-- EXEC dbo.Anexo_Combo 1, 1, 'IMPALAPER'
ALTER PROCEDURE [dbo].[Anexo_Combo]
@IdCompany INT,
@IdCompanyBranch INT,
@ClientNumber VARCHAR(32)
AS
SELECT
an.IdAnexo,
an.CodAnexo,
an.RucAnexo,
an.Direccion
FROM Anexo an
--INNER JOIN Client cl ON cl.IdClient = an.IdCliente
LEFT JOIN Client clRa ON clRa.IdCompany = an.IdCompany AND clRa.IdCompanyBranch = an.IdCompanyBranch AND clRa.IdClient = an.IdCliente --AND clRa.Ruc = an.RucAnexo
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND (@ClientNumber = '' OR TRIM(clRa.ClientNumber) = TRIM(@ClientNumber))
--AND an.IdStatus = @IdStatus