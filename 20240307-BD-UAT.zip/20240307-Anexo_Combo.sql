-- EXEC dbo.Anexo_Combo 1, 1, 'a'
ALTER PROCEDURE [dbo].[Anexo_Combo]
@IdCompany INT,
@IdCompanyBranch INT,
@ClientNumber VARCHAR(32)
AS
SELECT
an.IdAnexo,
an.CodAnexo,
an.RucAnexo,
an.Direccion,
ISNULL(clRa.ClientNumber, '') AS ClientNumber
FROM Anexo an
INNER JOIN Client cl ON cl.IdClient = an.IdCliente
LEFT JOIN Client clRa ON clRa.Ruc = an.RucAnexo
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND (@ClientNumber = '' OR TRIM(cl.ClientNumber) = TRIM(@ClientNumber))
--AND an.IdStatus = @IdStatus