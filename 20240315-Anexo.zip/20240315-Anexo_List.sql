-- EXEC dbo.Anexo_List 1, 0, -300, 1, '', 1, 14
ALTER PROCEDURE [dbo].[Anexo_List]
@IdCompany INT,
@IdCompanyBranch INT,
@TimeZone INT,
@IdStatus INT,
@Search VARCHAR(50),
@PageIndex INT,
@PageSize INT
AS

SET NOCOUNT ON
DECLARE @TotalElements INT

DECLARE @Base AS TABLE
(IdFila INT IDENTITY PRIMARY KEY,
IdCompany INT NOT NULL,
IdAnexo INT NOT NULL,
DeletedFlag BIT NOT NULL,
CodAnexo VARCHAR(20) NOT NULL,
RucAnexo VARCHAR(32) NOT NULL,
AnexoClientNumber VARCHAR(32) NULL,
IdUbigeo VARCHAR(50) NOT NULL,
IdCompanyBranch INT NOT NULL,
CompanyBranch VARCHAR(100) NOT NULL,
Direccion VARCHAR(250)NOT NULL,
IdCliente INT NOT NULL,
RucCliente VARCHAR(32), 
ClientNumber VARCHAR(32) NULL,
IdStatus INT NOT NULL,
CreatedCompany VARCHAR(100) NOT NULL,
[Status] VARCHAR(500) NOT NULL,
CreatedUser VARCHAR(100) NOT NULL,
CreatedDate VARCHAR(20) NOT NULL,
UpdatedCompany VARCHAR(100),
UpdatedUser VARCHAR(100),
UpdatedDate VARCHAR(20),
FlagDestinatario BIT
)

INSERT INTO @Base (IdCompany, IdAnexo, DeletedFlag, CodAnexo, RucAnexo, AnexoClientNumber, IdUbigeo, IdCompanyBranch, CompanyBranch, Direccion,
IdCliente, RucCliente, ClientNumber, IdStatus, [Status], CreatedCompany, CreatedUser, CreatedDate, UpdatedCompany,
UpdatedUser, UpdatedDate, FlagDestinatario)
SELECT
an.IdCompany,
an.IdAnexo,
an.DeletedFlag,
an.CodAnexo,
an.RucAnexo,
clAn.ClientNumber AS AnexoClientNumber,
an.IdUbigeo,
an.IdCompanyBranch,
cb.CodeCompanyBranch AS CompanyBranch,
an.Direccion,
an.IdCliente,
co.Ruc AS RucCliente,
co.ClientNumber,
an.IdStatus,
tblm.[Description] AS [Status],
com.CompanyName AS CreatedCompany,
us1.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), an.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.CreatedDate), 108) AS CreatedDate,
ISNULL(emp2.CompanyName, ' ') AS UpdatedCompany,
ISNULL(us2.UserLogin, ' ') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), an.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, an.UpdatedDate), 108), ' ') AS UpdatedDate,
ISNULL(FlagDestinatario, 0) AS FlagDestinatario
FROM Anexo an
LEFT JOIN Client co on co.IdClient = an.IdCliente
LEFT JOIN Client clAn on clAn.Ruc = an.RucAnexo
INNER JOIN MasterTable tblm ON tblm.IdTable = 1 AND tblm.IdColumn = an.IdStatus AND tblm.IdColumn > 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = an.IdCompany AND cb.IdCompanyBranch = an.IdCompanyBranch
INNER JOIN Company com ON com.IdCompany = an.CreatedIdCompany
INNER JOIN [User] us1 ON us1.IdCompany = an.IdCompany AND us1.IdUser = an.CreatedIdUser
LEFT JOIN Company emp2 ON emp2.IdCompany = an.UpdatedIdCompany
LEFT JOIN [User] us2 ON us2.IdCompany = an.IdCompany AND us2.IdUser = an.UpdatedIdUser
WHERE an.IdCompany = @IdCompany 
AND (an.IdCompanyBranch = @IdCompanyBranch OR @IdCompanyBranch = 0)
AND an.DeletedFlag = 0
AND an.IdStatus = @IdStatus
AND (an.CodAnexo LIKE '%' + @Search + '%'
	OR cb.CodeCompanyBranch LIKE '%' + @Search + '%'
	OR an.RucAnexo LIKE '%' + @Search + '%'
	OR @Search = ''
)

SELECT @TotalElements = COUNT(1) FROM @Base
SET NOCOUNT OFF

SELECT
IdCompany, 
IdAnexo,
DeletedFlag,
CodAnexo,
RucAnexo, 
ISNULL(AnexoClientNumber, '') AS AnexoClientNumber,
IdUbigeo, 
IdCompanyBranch,
CompanyBranch,
Direccion,
IdCliente, 
RucCliente,
ISNULL(ClientNumber, '') AS ClientNumber,
IdStatus,
[Status], 
CreatedCompany, 
CreatedUser, 
CreatedDate, 
UpdatedCompany,
UpdatedUser, 
UpdatedDate,
FlagDestinatario,
@TotalElements AS TotalElements
FROM @Base
ORDER BY IdAnexo ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY