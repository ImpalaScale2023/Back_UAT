--DECLARE @MENSAJE VARCHAR(MAX)    
--EXEC dbo.Weighing_InsertUpdate 1, 0, 'IS-2150998', '', 1, 1, 1, 1, 1, 'prueba', 28125, 0, 1, 0, 0, 0, 0, 1, 1, '', '', '', @MENSAJE OUTPUT    
--SELECT @MENSAJE    
ALTER PROCEDURE [dbo].[Weighing_InsertUpdate]
@IdCompany INT, --header    
@IdWeighing INT,     
@IdInbound VARCHAR(25),    
@IdOutbound VARCHAR(20),    
@IdCompanyBranch INT, --header    
@IdWeighingCycle INT,     
@IdWeighingType INT,    
@IdVehicle INT,    
@TruckNumber VARCHAR(20),  -- SI NO MANDA ''    
@TrailerNumber VARCHAR(20),  -- SI NO MANDA  ''    
@IdDriver INT,    
@DriverName VARCHAR(50),    
@DriverLicenseNumber VARCHAR(20),    
@IdContainer INT,    
@ContainerCode VARCHAR(20),      
@ContainerTareWeight INT,    
@IdBascule INT,    
@Observation VARCHAR(200),     
@Weight INT,    
@Weight2 INT,    
@CaptureType INT,    
@IdUser INT,    
@ReInputType INT,    
@ReInputFlag BIT,    
@QuantityBags INT,    
@IdLoadType INT,    
@ManualAxleSetFlag BIT,    
@VehicleTareFlag BIT,    
    
@QuantityImpala INT,    
@QuantitySupervisor INT,    
    
@UcUnload VARCHAR(200),    
@Load VARCHAR(50),    
@OriginPort VARCHAR(50),    
@DestinationPort VARCHAR(50),    
@Buque VARCHAR(50),    
@IdCompanyAud INT,    
@IdUserAud INT,    
@TWeighingAxle TWeighingAxle READONLY,
@SealLine VARCHAR(150),
@SealSupervisor VARCHAR(150),
@SealCustoms VARCHAR(150),
@DeliveryAddress VARCHAR(100),
@Guide VARCHAR(20),
@Lot INT,
@Error VARCHAR(MAX) OUTPUT    
AS    
BEGIN TRAN    
BEGIN TRY    
DECLARE     
 @WeighingNumber INT,    
     
 @ReportedGrossWeight INT,     
 @ReportedTareWeight INT,     
 @ReportedNetWeight INT,    
 @ReportedTolerance INT,    
 @NetWeight INT,
 @WaterWeight INT = 0,
    
 @IdStatus INT,    
 @IdCountry INT,
 @ReInputStatus INT -- Capturar el Estado
 --@DocumentGrossWeight INT,    
 --@DocumentTareWeight INT,    
 --@DocumentNetWeight INT,    
 --@WeightTolerance INT    
DECLARE --VEHICLE    
 @IdVehicleConfiguration INT,    
 --@TruckPlate VARCHAR(20),    
 --@TrailerPlate VARCHAR(20),    
 @IdTrailerType INT,    
 @TruckLong DECIMAL(18, 2),    
 @TruckWidth DECIMAL(18, 2),    
 @TruckHigh DECIMAL(18, 2),    
 @BonusFlag BIT,    
 @BonusLimitWeighing INT,    
 @BonusExpirationDate DATE    
DECLARE --INBOUND    
 @SupplierNumber VARCHAR(32),    
 @SupplierName VARCHAR(40),    
 @IdCarrier INT,    
 @CarrierName VARCHAR(100),    
 @CarrierCode VARCHAR(20),    
 @CarrierAdrress VARCHAR(100),    
 @ItemNumber VARCHAR(50),    
 @Quality VARCHAR(100),    
 @LotNumber VARCHAR(25),    
 @SupplierLotNumber VARCHAR(25),    
 @StorageLocation VARCHAR(100),    
 @NumberGuideWaybill VARCHAR(20),    
 @IdClient INT,     
 @ClientNumber VARCHAR(32),
 --@IdDriver INT,    
 --@Driver VARCHAR(50),    
 --@LicenseNumber VARCHAR(20),    
 @WarehouseCode VARCHAR(32)    
DECLARE --OUTBOUND    
 @QtyOutbound INT,
 @IdProduct INT,
 @Product VARCHAR(40)
    
DECLARE @Sequence INT,    
  @_ERROR VARCHAR(200),
  @CodeWareHouse VARCHAR(3),
  @Count INT,
  @TruckId VARCHAR(10) = ''

SET @Error = ''+','+'0'+','+'0'+','+'0' -- 1 messege error, 2 idweighing, 3 idstatus, 4 idweinghingcycle    
IF @IdVehicle = 0 AND TRIM(TRIM(@TruckNumber)) = '' AND TRIM(TRIM(@TrailerNumber)) = ''    
BEGIN     
;THROW 50002, '#VALID! The Truck AND Trailer Number are empty', 1    
END
IF @IdWeighing > 0 AND @IdWeighingCycle = 2 AND @IdLoadType = 3
BEGIN
	IF(TRIM(@SealLine) = '' OR TRIM(@SealSupervisor) = '' OR TRIM(@SealCustoms) = '')
	BEGIN
		;THROW 50002, '#VALID! The Seal Line OR Seal Supervisor OR Seal Customs TEXT are empty', 1    
	END
END
--IF @IdDriver = 0 AND TRIM(@DriverName) = '' AND TRIM(@DriverLicenseNumber) = ''    
--BEGIN     
--;THROW 50002, '#VALID! The Name AND LicenseNumber Driver are empty', 1    
--END    
IF @Weight <= 0   
BEGIN     
;THROW 50002, '#VALID! the weight value cannot be less than or equal to zero', 1    
END  
    
IF @IdWeighingCycle = 1 --RECEPCION    
BEGIN    
 SELECT     
 @ReportedGrossWeight = CONVERT(INT, INV_ATTR_STR11),    
 @ReportedTareWeight = CONVERT( INT, INV_ATTR_STR12),    
 @ReportedNetWeight = CONVERT(INT, INV_ATTR_STR10),    
 @ReportedTolerance =  CONVERT(INT, UC_TOLERANCE)    
 FROM UC_MASTER_RECEIPT_FWD WHERE TRKNUM = @IdInbound    
END    
ELSE IF @IdWeighingCycle = 2 --DESPACHO    
BEGIN    
	SET @ReportedGrossWeight = 0    
	SET @ReportedTareWeight = 0    
	SET @ReportedNetWeight = 0 
	SET @ReportedTolerance = 0 
 
	SELECT @CodeWareHouse = CodeCompanyBranch FROM CompanyBranch WHERE IdCompanyBranch = @IdCompanyBranch
	SELECT @Count = COUNT(1) + 1 FROM Weighing WHERE IdCompany = @IdCompany 
													AND IdCompanyBranch = @IdCompanyBranch 
													--AND DeletedFlag = 0 
													AND RIGHT(YEAR(CreatedDate), 2) = RIGHT(YEAR(GETDATE()), 2)
													AND IdWeighingCycle = @IdWeighingCycle
	SELECT @TruckId = @CodeWareHouse + RIGHT(YEAR(GETDATE()), 2) + REPLACE(STR(@Count, 5), ' ', '0')
END    
    
-- VEHICLE    
IF @IdVehicle = 0     
BEGIN     
 SET @IdVehicleConfiguration = NULL    
 SET @IdTrailerType = 1    
 SET @TruckLong = 0    
 SET @TruckWidth = 0    
 SET @TruckHigh = 0    
 SET @BonusFlag = 0    
 SET @BonusLimitWeighing = 0    
 SET @BonusExpirationDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
    
     
 IF EXISTS (SELECT 1 FROM Vehicle WHERE IdCompany = @IdCompany     
    AND TruckNumber = TRIM(@TruckNumber) AND TrailerNumber = TRIM(@TrailerNumber) AND DeletedFlag = 0
	AND IdCompanyBranch = @IdCompanyBranch)    
 BEGIN    
  SELECT @IdVehicle = IdVehicle, @IdVehicleConfiguration = IdVehicleConfiguration     
  FROM Vehicle WHERE IdCompany = @IdCompany     
  AND TruckNumber = TRIM(@TruckNumber) AND TrailerNumber = TRIM(@TrailerNumber) AND DeletedFlag = 0
  AND IdCompanyBranch = @IdCompanyBranch
 END    
 ELSE    
 BEGIN    
  SELECT @IdVehicle = ISNULL(MAX(IdVehicle), 0) + 1 FROM Vehicle    
  INSERT INTO Vehicle(IdCompany, IdVehicle, RFID, IdVehicleConfiguration, TruckNumber, TruckLong, TruckWidth,     
     TruckHigh, TruckInscription, TruckTare, TruckBrand, TruckModel, TruckMotor, IdTrailerType,     
     TrailerNumber, TrailerLong, TrailerWidth, TrailerHigh, TrailerInscription, TrailerTare,    
     BonusFlag, BonusExpirationDate, BonusMaxGrossWeight, IdCarrier, IdDriver,    
     IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)    
  VALUES (@IdCompany, @IdVehicle, '', @IdVehicleConfiguration, TRIM(@TruckNumber), @TruckLong, @TruckWidth, @TruckHigh,     
    '', 0, 0, '', '', @IdTrailerType, TRIM(@TrailerNumber), 0, 0, 0, '', 0, @BonusFlag, @BonusExpirationDate, 0, @IdCarrier,    
    @IdDriver, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)    
 END    
END    
ELSE    
BEGIN    
 SELECT     
 @IdVehicleConfiguration = IdVehicleConfiguration,    
 @TruckNumber = TRIM(TruckNumber),    
 @TrailerNumber = TRIM(TrailerNumber),    
 @IdTrailerType = IdTrailerType,    
 @TruckLong = TruckLong,    
 @TruckWidth = TruckWidth,    
 @TruckHigh = TruckHigh,    
 @BonusFlag = BonusFlag,    
 @BonusLimitWeighing = (SELECT ISNULL(SUM(Limit), 0) FROM VehicleBonus WHERE IdCompany = @IdCompany AND IdVehicle = @IdVehicle),    
 @BonusExpirationDate = BonusExpirationDate    
 FROM Vehicle WHERE IdCompany = @IdCompany AND IdVehicle = @IdVehicle    
END    
    
-- DRIVER    
IF @IdDriver = 0     
BEGIN    
 SELECT @IdCountry = IdCountry FROM Company WHERE IdCompany = @IdCompany    
 IF EXISTS (SELECT 1 FROM Driver WHERE IdCompany = @IdCompany     
   AND LicenseNumber = @DriverLicenseNumber AND DeletedFlag = 0)    
 BEGIN    
  SELECT @IdDriver = IdDriver FROM Driver WHERE IdCompany = @IdCompany     
   AND LicenseNumber = @DriverLicenseNumber AND DeletedFlag = 0    
  UPDATE Driver SET    
  Driver = @DriverName,    
  UpdatedIdCompany = @IdCompanyAud,    
  UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
  UpdatedIdUser = @IdUserAud    
  WHERE IdDriver = @IdDriver AND IdCompany = @IdCompany    
 END    
 ELSE    
 BEGIN    
  SELECT @IdDriver = ISNULL(MAX(IdDriver), 0) + 1 FROM Driver    
  INSERT INTO Driver (IdCompany, IdDriver, Driver, IdCountry, IdNumber, LicenseNumber, IdStatus, DeletedFlag,     
     CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)    
  VALUES (@IdCompany, @IdDriver, @DriverName, @IdCountry, 1, @DriverLicenseNumber, 1, 0, @IdCompanyAud, @IdUserAud,     
    dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)    
 END    
END    
ELSE    
BEGIN     
 SELECT    
 @DriverName = Driver,    
 @DriverLicenseNumber = LicenseNumber    
 FROM Driver WHERE IdCompany = @IdCompany AND IdDriver = @IdDriver    
END    
    
-- CONTAINER    
IF @IdContainer = 0 AND TRIM(@ContainerCode) = ''    
BEGIN    
 SET @IdContainer = NULL    
END    
ELSE    
BEGIN    
 IF EXISTS (SELECT 1 FROM Container WHERE IdCompany = @IdCompany AND ContainerCode = @ContainerCode AND DeletedFlag=0)    
 BEGIN    
  SELECT @IdContainer = IdContainer FROM Container     
  WHERE IdCompany = @IdCompany AND ContainerCode = @ContainerCode AND DeletedFlag=0    
  UPDATE Container SET     
  ContainerTareWeight = @ContainerTareWeight,    
  UpdatedIdCompany = @IdCompanyAud,    
  UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
  UpdatedIdUser = @IdUserAud
  WHERE IdCompany = @IdCompany AND IdContainer= @IdContainer    
 END    
 ELSE    
 BEGIN    
  SELECT @IdContainer = ISNULL(MAX(IdContainer), 0) + 1 FROM Container    
  INSERT INTO Container (IdCompany, IdContainer, ContainerCode, ContainerTareWeight, IdStatus, DeletedFlag, CreatedIdCompany,    
     CreatedIdUser, CreatedDate, IdCompanyBranch)    
  VALUES (@IdCompany, @IdContainer, @ContainerCode, @ContainerTareWeight, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)    
 END    
END    

IF @IdWeighing = 0    
BEGIN    
 SELECT @IdWeighing = ISNULL(MAX(IdWeighing), 0) + 1 FROM Weighing    
 SELECT @WeighingNumber = ISNULL(MAX(WeighingNumber), 0) + 1 FROM Weighing     
  WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch    
    
 IF @CaptureType = 3    
 BEGIN    
  IF @Weight2 = 0    
  BEGIN    
   SET @IdStatus = 1    
   SET @NetWeight = 0    
  END    
  ELSE    
  BEGIN    
   SET @IdStatus = 3    
   SET @NetWeight = @Weight - @Weight2    
  END    
 END    
 ELSE    
 BEGIN    
  SET @IdStatus = 1    
  SET @NetWeight = 0    
 END    
     
 IF @IdWeighingCycle = 1 --RECEPCION    
 BEGIN    
    
  SELECT    
  @SupplierNumber = SUPNUM,    
  @SupplierName = ADRNAM_SUP,    
  --@IdCarrier = ,    
  @CarrierName = CARNAM,    
  @CarrierCode = CARCOD,    
  --@CarrierAdrress = ,    
  @ItemNumber = PRTNUM,    
  @Quality = INV_ATTR_STR1,    
  @LotNumber = LOTNUM,    
  @SupplierLotNumber = SUP_LOTNUM,    
  @StorageLocation = STOLOC,    
  @NumberGuideWaybill = TRKREF,    
  --@IdClient = ,     
  @ClientNumber = CLIENT_ID,    
  --@IdDriver = ,    
  --@Driver = DRIVER_NAM,    
  --@LicenseNumber = DRIVER_LIC_NUM,    
  --@IdContainer = ,    
  --@ContainerCode = INV_ATTR_STR13,    
  --@ContainerTareWeight 
  @Product = PRTNUM,
  @WarehouseCode = WHSE_ID,
  @ContainerCode = INV_ATTR_STR13
  FROM UC_MASTER_RECEIPT_FWD WHERE TRKNUM = @IdInbound    
    
  SET @Sequence = ISNULL((SELECT MAX(Sequence) FROM Weighing     
   WHERE LotNumber = @LotNumber AND IdCompany = @IdCompany AND DeletedFlag=0),0) + 1    
      
 END    
 ELSE IF @IdWeighingCycle = 2 --DESPACHO    
 BEGIN  
	SELECT @IdCarrier = ISNULL(IdCarrier, NULL) FROM Vehicle WHERE IdCompany = @IdCompany AND IdVehicle = @IdVehicle
  SELECT    
  @CarrierName = Carrier,    
  @CarrierCode = CarrierCode,
  @CarrierAdrress = [Address]
  FROM Carrier WHERE IdCompany = @IdCompany AND IdCarrier = @IdCarrier

  SELECT    
  @SupplierNumber = 'a',     
  @SupplierName = ' ',    
  --@IdCarrier = ,    
  --@CarrierName = '', --  PENDIENTE    
  --@CarrierCode = '', --PENDIENTE    
  --@CarrierAdrress = ,    
  @ItemNumber = PRTNUM,    
  @Quality = INV_ATTR_STR1,    
  @LotNumber = ' ',    
  @QtyOutbound = CAST(QTY AS INT),    
  @SupplierLotNumber = ' ',    
  @StorageLocation = STOLOC,    
  @NumberGuideWaybill = '',    
  --@IdClient = ,     
  @ClientNumber = CLIENT_ID,    
  --@IdDriver = ,    
  --@Driver = DRIVER_NAM,  PENDIENTE O EL USUARIO SELECCIONA  O LA TABLA PERMITE NULL    
  --@LicenseNumber = DRIVER_LIC_NUM,  PENDIENTE    
  --@IdContainer = ,    
  --@ContainerCode = INV_ATTR_STR13    PENDIENTE    
  --@ContainerTareWeight
  @Product = PRTNUM,
  @WarehouseCode = WHSE_ID    
  FROM UC_PICK_TO_SCALE WHERE ORDNUM = @IdOutbound    
  --;THROW 50002, '#VALID! The Outbound not suport', 1    
    
  SET @Sequence = ISNULL((SELECT MAX(Sequence) FROM Weighing     
   WHERE IDOUTBOUND = @IdOutbound AND IdCompany = @IdCompany AND DeletedFlag=0),0) + 1    
      
 END    
      
 IF @IdWeighingCycle = 1 --RECEPCION    
 BEGIN    
  IF EXISTS (SELECT 1 FROM Carrier WHERE IdCompany = @IdCompany AND CarrierCode = @CarrierCode) --EXISTE LA VARIABLE @CARIERCODE EN LA TABLA CARIER    
  BEGIN    
   SELECT @IdCarrier = IdCarrier, @CarrierAdrress = [Address] FROM Carrier     
   WHERE IdCompany = @IdCompany AND CarrierCode = @CarrierCode    
  END    
  ELSE    
  BEGIN    
   SET @CarrierAdrress = ''    
   SELECT @IdCarrier = ISNULL(MAX(IdCarrier), 0) + 1 FROM Carrier    
   INSERT INTO Carrier(IdCompany, IdCarrier, CarrierCode, Carrier, [Address], IdStatus, DeletedFlag,     
      CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)    
   VALUES (@IdCompany, @IdCarrier, @CarrierCode, @CarrierName, @CarrierAdrress, 1, 0, @IdCompanyAud,     
   @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)    
  END    
    
  IF EXISTS (SELECT 1 FROM Client WHERE IdCompany = @IdCompany AND ClientNumber = @ClientNumber AND DeletedFlag = 0)    
  BEGIN    
   SELECT @IdClient = IdClient FROM Client WHERE IdCompany = @IdCompany AND ClientNumber = @ClientNumber AND IdCompanyBranch = @IdCompanyBranch   
  END    
  ELSE    
  BEGIN    
   SELECT @IdClient = ISNULL(MAX(IdClient), 0) + 1 FROM Client    
   INSERT INTO Client (IdCompany, IdClient, ClientNumber, BusinessName, Ruc, [Address], IdTurn, IdTypePerson, FlagBillingAddress,     
      IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)    
   VALUES (@IdCompany, @IdClient, @ClientNumber,' ', '', '', 1, 1, 0, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @IdCompanyBranch)    
  END    
     
  IF EXISTS (SELECT 1 FROM Product WHERE IdCompany = @IdCompany AND CodProduct = @Product)    
  BEGIN    
   SELECT @Product = CodProduct FROM Product WHERE IdCompany = @IdCompany AND CodProduct = @Product    
  END    
  ELSE    
  BEGIN    
   SELECT @IdProduct = ISNULL(MAX(IdProduct), 0) + 1 FROM Product    
   INSERT INTO Product(IdCompany, IdProduct, IdCompanyBranch, CodProduct, DescProduct,     
      IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate)    
   VALUES (@IdCompany, @IdProduct, @IdCompanyBranch, @Product,' ', 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch))    
  END 

  UPDATE UC_MASTER_RECEIPT_FWD SET    
  UC_UNLOAD = @UcUnload,    
  UpdatedIdCompany = @IdCompanyAud,    
  UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
  UpdatedIdUser = @IdUserAud    
  WHERE TRKNUM = @IdInbound    
    
  --SET @Error = '' +','+ convert(varchar(10),@IdWeighing) +','+ convert(varchar(1),@IdStatus)+','+ convert(varchar(1),@IdWeighingCycle)    
 END    
 ELSE IF @IdWeighingCycle = 2--DESPACHO    
 BEGIN    
    
  IF EXISTS (SELECT 1 FROM Client WHERE IdCompany = @IdCompany AND ClientNumber = @ClientNumber AND IdCompanyBranch = @IdCompanyBranch )    
  BEGIN    
   SELECT @IdClient = IdClient FROM Client WHERE IdCompany = @IdCompany AND ClientNumber = @ClientNumber AND IdCompanyBranch = @IdCompanyBranch 
  END    
  ELSE    
  BEGIN    
   SELECT @IdClient = ISNULL(MAX(IdClient), 0) + 1 FROM Client    
   INSERT INTO Client (IdCompany, IdClient, ClientNumber, BusinessName, Ruc, [Address], IdTurn, IdTypePerson, FlagBillingAddress,     
      IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate, IdCompanyBranch)    
   VALUES (@IdCompany, @IdClient, @ClientNumber,' ', '', '', 1, 1, 0, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
   , @IdCompanyBranch)    
  END    
 END    
 IF EXISTS (SELECT 1 FROM Product WHERE IdCompany = @IdCompany AND CodProduct = @Product)    
  BEGIN    
   SELECT @Product = CodProduct FROM Product WHERE IdCompany = @IdCompany AND CodProduct = @Product    
  END    
  ELSE    
  BEGIN    
   SELECT @IdProduct = ISNULL(MAX(IdProduct), 0) + 1 FROM Product    
   INSERT INTO Product(IdCompany, IdProduct, IdCompanyBranch, CodProduct, DescProduct,     
      IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate)    
   VALUES (@IdCompany, @IdProduct, @IdCompanyBranch, @Product,' ', 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch))    
  END 

 INSERT INTO Weighing (IdCompany, IdWeighing, IDINBOUND, IDOUTBOUND, IdCompanyBranch, IdWeighingCycle, IdWeighingType,     
    WeighingNumber, IdVehicleConfiguration, IdVehicle, TruckPlate, TrailerPlate, IdTrailerType, TruckLong,     
    TruckWidth, TruckHigh, SupplierNumber, SupplierName, IdCarrier, Carrier, CarrrierAddress, ItemNumber,    
    Quality, LotNumber, SupplierLotNumber, StorageLocation, NumberGuideWaybill, IdClient, ClientCode,    
    WarehouseCode, InputIdBascule, InputIdDriver, InputDriver, InputLicenseDriver, InputObs, InputWeight, OutputWeight,      
    InputCaptureType, InputIdContainer, InputContainerCode, InputContainerTareWeight, InputIdUser, InputDate, QuantityBags, IdLoadType, ReportedGrossWeight,
	ReportedTareWeight, ReportedNetWeight, ReportedTolerance,NetWeight, ManualAxleSetFlag,     
    VehicleTareFlag, BonusFlag, BonusLimitWeighing, BonusExpirationDate, QuantityImpala, QuantitySupervisor, [Sequence], [load], SealLine, 
	SealSupervisor, SealCustoms, IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate, DeliveryAddress, TruckId, GuideNumber, Lot)    
 VALUES (@IdCompany, @IdWeighing, @IdInbound, @IdOutbound, @IdCompanyBranch, @IdWeighingCycle, @IdWeighingType,     
   @WeighingNumber, @IdVehicleConfiguration, @IdVehicle, TRIM(@TruckNumber), TRIM(@TrailerNumber), @IdTrailerType, @TruckLong,     
   @TruckWidth, @TruckHigh, @SupplierNumber, @SupplierName, @IdCarrier, @CarrierName, @CarrierAdrress, @ItemNumber,     
   @Quality, @LotNumber, @SupplierLotNumber, @StorageLocation, @NumberGuideWaybill, @IdClient, @ClientNumber,    
   @WarehouseCode, @IdBascule, @IdDriver, @DriverName, @DriverLicenseNumber, @Observation, @Weight, @Weight2, @CaptureType,     
   @IdContainer, @ContainerCode, @ContainerTareWeight, @IdUser, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), @QuantityBags, @IdLoadType, @ReportedGrossWeight, 
   @ReportedTareWeight, @ReportedNetWeight, @ReportedTolerance, @NetWeight, @ManualAxleSetFlag, @VehicleTareFlag,    
   @BonusFlag, @BonusLimitWeighing, @BonusExpirationDate, @QuantityImpala, @QuantitySupervisor,     
   @Sequence, @Load, @SealLine, @SealSupervisor, @SealCustoms, @IdStatus, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch), 
   @DeliveryAddress, @TruckId, @Guide, @Lot)
  
	IF @CaptureType = 3    
	BEGIN    
		IF @Weight2 > 0    
		BEGIN    
			UPDATE Weighing SET   
			GuideNumber = @Guide,
			OutputIdBascule = @IdBascule,     
			OutputIdDriver = @IdDriver,     
			OutputDriver = @DriverName,    
			OutputLicenseDriver = @DriverLicenseNumber,    
			OutputObs = @Observation,     
			OutputCaptureType = @CaptureType,
			OutputIdContainer = @IdContainer,     
			OutputContainerCode = @ContainerCode,     
			OutputContainerTareWeight = @ContainerTareWeight, 
			OutputIdUser = @IdUser,     
			OutputDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
			UpdatedIdCompany = @IdCompanyAud,    
			UpdatedIdUser = @IdUserAud,
			UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)
			WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing    

			IF @NetWeight <= 0 
			BEGIN     
				;THROW 50002, '#VALID! Gross Weight cannot be less than or equal to Tare Weight', 1    
			END
		END
		
	 END  
   
 DECLARE @IdWeighingAxleGroupMax INT    
 SELECT @IdWeighingAxleGroupMax = ISNULL(MAX(IdWeighingAxleGroup), 0) + 1 FROM WeighingAxleGroup    
 INSERT INTO WeighingAxleGroup    
 (IdCompany, IdWeighingAxleGroup, Idweighing, IdAxleGroup, AxleSet, TareWeight, GrossWeight,  NetWeight,     
 Limit, Tolerance, IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate)    
 SELECT    
 @IdCompany, ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) + @IdWeighingAxleGroupMax,     
 @IdWeighing, IdAxleGroup, AxleGroup,     
 CASE WHEN @IdWeighingCycle = 2 THEN [weight] ELSE 0 END,    
 CASE WHEN @IdWeighingCycle = 1 THEN [weight] ELSE 0 END,    
 0, Limit, Tolerance, 1, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
 FROM @TWeighingAxle    
    
 UPDATE UC_PICK_TO_SCALE SET    
 OriginPort = @OriginPort,    
 DestinationPort = @DestinationPort,    
 Buque = @Buque,    
 UpdatedIdCompany = @IdCompanyAud,    
 UpdatedIdUser = @IdUserAud,    
 UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
 WHERE ORDNUM = @IdOutbound    
    
END    
ELSE --@IdWeighing > 0    
BEGIN    
 IF @IdWeighingCycle = 1 --RECEPCION    
 BEGIN     
    
  IF @ReInputFlag = 1 --Re-Peso    
  BEGIN  
  
   SELECT @WaterWeight = InputWeight - @Weight FROM Weighing WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND IdWeighing=@IdWeighing  
   SET @NetWeight = -1    
   SET @IdStatus = 2    
   UPDATE Weighing SET  
	GuideNumber = @Guide,  
	ReInputIdBascule = @IdBascule,    
	ReInputIdDriver = @IdDriver,     
	ReInputDriver = @DriverName,     
	ReInputLicenseDriver = @DriverLicenseNumber,     
	ReInputObs = @Observation,     
	ReInputWeight = @Weight,   
	ReInputCaptureType = @CaptureType,
	ReInputIdContainer = @IdContainer,
	ReInputContainerCode = @ContainerCode,
	ReInputContainerTareWeight = @ContainerTareWeight,
	ReInputIdUser = @IdUser,     
	ReInputDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),     
	ReInputType = @ReInputType,    
	IdStatus = @IdStatus,    
	UpdatedIdCompany = @IdCompanyAud,    
	UpdatedIdUser = @IdUserAud,     
	UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	DeliveryAddress = @DeliveryAddress,
	WaterWeight = @WaterWeight
   WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing    
  END    
  ELSE -- Salida    
  BEGIN  
   SELECT @ReInputStatus = IdStatus FROM Weighing WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND IdWeighing=@IdWeighing    
   SELECT @NetWeight = IIF(@ReInputStatus = 1, InputWeight, ReInputWeight) - @Weight FROM Weighing WHERE IdCompany = @IdCompany AND IdCompanyBranch = @IdCompanyBranch AND IdWeighing=@IdWeighing    
   SET @IdStatus = 3    
    
   UPDATE Weighing SET
	GuideNumber = @Guide,  
	IdVehicle = @IdVehicle,     
	TruckPlate = TRIM(@TruckNumber),     
	TrailerPlate = TRIM(@TrailerNumber),     
	IdTrailerType = @IdTrailerType,     
	TruckLong = @TruckLong,    
	TruckWidth = @TruckWidth,     
	TruckHigh = @TruckHigh,     
	BonusFlag = @BonusFlag,     
	BonusLimitWeighing = @BonusLimitWeighing,     
	BonusExpirationDate = @BonusExpirationDate,    
	ReportedGrossWeight = @ReportedGrossWeight,    
	ReportedTareWeight = @ReportedTareWeight,    
	ReportedNetWeight = @ReportedNetWeight,    
	ReportedTolerance = @ReportedTolerance,    
	NetWeight = @NetWeight,    
	OutputIdBascule = @IdBascule,     
	OutputIdDriver = @IdDriver,     
	OutputDriver = @DriverName,    
	OutputLicenseDriver = @DriverLicenseNumber,    
	OutputObs = @Observation,     
	OutputWeight = @Weight,     
	OutputCaptureType = @CaptureType,
	OutputIdContainer = @IdContainer,     
	OutputContainerCode = @ContainerCode,     
	OutputContainerTareWeight = @ContainerTareWeight, 
	OutputIdUser = @IdUser,     
	OutputDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
	IdLoadType = @IdLoadType,    
	QuantityBags = @QuantityBags,    
	QuantityImpala = @QuantityImpala,    
	QuantitySupervisor = @QuantitySupervisor,
	SealLine = @SealLine,
	SealSupervisor = @SealSupervisor,
	SealCustoms = @SealCustoms,
	IdStatus = @IdStatus,    
	UpdatedIdCompany = @IdCompanyAud,    
	UpdatedIdUser = @IdUserAud,     
	UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	DeliveryAddress = @DeliveryAddress
   WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing    
    
       
   UPDATE axle SET    
   axle.TareWeight = wa.[weight],    
   axle.NetWeight = wa.[weight] - axle.GrossWeight,    
   axle.UpdatedIdCompany = @IdCompanyAud,    
   axle.UpdatedIdUser = @IdUserAud,    
   axle.UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
   FROM WeighingAxleGroup axle    
   INNER JOIN @TWeighingAxle wa ON wa.IdAxleGroup = axle.IdAxleGroup    
   WHERE axle.IdCompany = @IdCompany AND axle.IdWeighing = @IdWeighing    
    
   UPDATE UC_MASTER_RECEIPT_FWD SET    
   UC_UNLOAD = @UcUnload,    
   UpdatedIdCompany = @IdCompanyAud,    
   UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
   UpdatedIdUser = @IdUserAud    
   WHERE TRKNUM = @IdInbound    
    
  -- SET @Error = '' +','+ convert(varchar(10),@IdWeighing) +','+ convert(varchar(1),@IdStatus)+','+ convert(varchar(1),@IdWeighingCycle)    
  END    
 END    
 ELSE IF @IdWeighingCycle = 2 --DESPACHO    
 BEGIN 
  DECLARE  @InputContainerTare INT
  SELECT @InputContainerTare = InputContainerTareWeight FROM Weighing WHERE IdWeighing = @IdWeighing

  IF(@InputContainerTare = 0 AND @ContainerTareWeight = 0)
  BEGIN
	SELECT @NetWeight = @Weight - InputWeight FROM Weighing WHERE IdCompany = @IdCompany AND IdWeighing=@IdWeighing 
  END
  ELSE IF(@InputContainerTare > 0)
  BEGIN
	SELECT @NetWeight = @Weight - InputWeight FROM Weighing WHERE IdCompany = @IdCompany AND IdWeighing=@IdWeighing 
  END
  ELSE --IF(@ContainerTareWeight > 0)
  BEGIN
	SELECT @NetWeight = @Weight - InputWeight - @ContainerTareWeight FROM Weighing WHERE IdCompany = @IdCompany AND IdWeighing=@IdWeighing 
  END
  SET @IdStatus = 2    
    
  UPDATE Weighing SET
	GuideNumber = @Guide,  
	IdVehicle = @IdVehicle,     
	TruckPlate = TRIM(@TruckNumber),     
	TrailerPlate = TRIM(@TrailerNumber),     
	IdTrailerType = @IdTrailerType,     
	TruckLong = @TruckLong,    
	TruckWidth = @TruckWidth,     
	TruckHigh = @TruckHigh,     
	BonusFlag = @BonusFlag,     
	BonusLimitWeighing = @BonusLimitWeighing,     
	BonusExpirationDate = @BonusExpirationDate,
	ReportedGrossWeight = @ReportedGrossWeight,    
	ReportedTareWeight = @ReportedTareWeight,    
	ReportedNetWeight = @ReportedNetWeight,    
	ReportedTolerance = @ReportedTolerance,    
	NetWeight = @NetWeight,    
	OutputIdBascule = @IdBascule,     
	OutputIdDriver = @IdDriver,     
	OutputDriver = @DriverName,    
	OutputLicenseDriver = @DriverLicenseNumber,    
	OutputObs = @Observation,     
	OutputWeight = @Weight,     
	OutputCaptureType = @CaptureType,
	OutputIdContainer = @IdContainer,     
	OutputContainerCode = @ContainerCode,     
	OutputContainerTareWeight = @ContainerTareWeight, 
	OutputIdUser = @IdUser,     
	OutputDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),    
	IdLoadType = @IdLoadType,    
	QuantityBags = @QuantityBags,    
	QuantityImpala = @QuantityImpala,    
	QuantitySupervisor = @QuantitySupervisor,    
	[Load] = @Load,
	SealLine = @SealLine,
	SealSupervisor = @SealSupervisor,
	SealCustoms = @SealCustoms,
	IdStatus = @IdStatus,    
	UpdatedIdCompany = @IdCompanyAud,    
	UpdatedIdUser = @IdUserAud,     
	UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
	DeliveryAddress = @DeliveryAddress,
	Lot = @Lot
  WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing    
      
  UPDATE axle SET    
  axle.GrossWeight = wa.[weight],    
  axle.NetWeight = wa.[weight] - axle.TareWeight,    
  axle.UpdatedIdCompany = @IdCompanyAud,    
  axle.UpdatedIdUser = @IdUserAud,    
  axle.UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
  FROM WeighingAxleGroup axle    
  INNER JOIN @TWeighingAxle wa ON wa.IdAxleGroup = axle.IdAxleGroup    
  WHERE axle.IdCompany = @IdCompany AND axle.IdWeighing = @IdWeighing    
    
  UPDATE UC_PICK_TO_SCALE SET    
  OriginPort = @OriginPort,    
  DestinationPort = @DestinationPort,    
  Buque = @Buque,    
  UpdatedIdCompany = @IdCompanyAud,    
  UpdatedIdUser = @IdUserAud,    
  UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch)    
  WHERE ORDNUM = @IdOutbound    
    
  --SET @Error = '' +','+ convert(varchar(10),@IdWeighing) +','+ convert(varchar(1),@IdStatus)+','+ convert(varchar(1),@IdWeighingCycle)    
 END    
IF @NetWeight <= 0 AND @ReInputFlag != 1
BEGIN     
	;THROW 50002, '#VALID! Gross Weight cannot be less than or equal to Tare Weight', 1    
END
END    
    
IF (SELECT COUNT(*) FROM Weighing WHERE IDINBOUND = @IdInbound AND @IdWeighingCycle = 1 AND DeletedFlag = 0)>1    
BEGIN    
 ;THROW 50002, '#VALID! The Inbound is being used by another weighing', 1    
END

--IF (SELECT COUNT(*) FROM Weighing WHERE IDOUTBOUND = @IdOutbound AND @IdWeighingCycle = 2 AND DeletedFlag = 0)>1    
--BEGIN    
-- ;THROW 50002, '#VALID! The Outbound is being used by another weighing', 1    
--END    
--IF (SELECT SUM(NetWeight) FROM Weighing     
--  WHERE IDOUTBOUND = @IdOutbound AND @IdWeighingCycle = 2 AND DeletedFlag = 0) > @QtyOutbound    
--BEGIN    
-- SET @_ERROR = '#VALID! The weight is greater than the limit of The Outbound. QTY = '+ CAST(@QtyOutbound AS VARCHAR)    
-- ;THROW 50002, @_ERROR, 1    
--END    
    SET @Error = '' +','+ convert(varchar(10),@IdWeighing) +','+ convert(varchar(1),@IdStatus)+','+ convert(varchar(1),@IdWeighingCycle)  
COMMIT TRAN    
    
END TRY    
BEGIN CATCH    
 ROLLBACK TRAN    
 SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())    
END CATCH 
