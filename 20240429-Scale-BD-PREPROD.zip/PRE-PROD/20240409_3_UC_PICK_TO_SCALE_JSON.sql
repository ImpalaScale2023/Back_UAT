-- [UC_PICK_TO_SCALE_JSON] 1, -10, 101, 4, 1
ALTER PROCEDURE [dbo].[UC_PICK_TO_SCALE_JSON] 
@IdCompany INT,
@TimeZone INT,
@IdWeighing INT,
@IdTransferReason INT,
@IdTransferModality INT
AS
DECLARE @IdWeighingCycle INT, @IdStatus INT,
@Dam VARCHAR(20),
@serieDam VARCHAR(5),
@correlativoDam VARCHAR(20)
		
	SELECT 
	@IdWeighingCycle = IdWeighingCycle, @IdStatus = IdStatus 
	FROM Weighing WHERE IdCompany = @IdCompany AND IdWeighing = @IdWeighing

	SELECT @Dam = ISNULL(uc.DAM, '')
	FROM Weighing we
	LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
	WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
	AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
	IF CHARINDEX('-', @Dam) > 0 AND @IdTransferReason = 2
	BEGIN
	SELECT @serieDam = SUBSTRING(@Dam, 1, CHARINDEX('-', @Dam) - 1);
	SELECT @correlativoDam = SUBSTRING(@Dam, LEN(@serieDam) + 2, LEN(@Dam) - LEN(@serieDam))
	END
	

SELECT
--CONDUCTOR
dro.DriverLastName AS ApellConductor, 
dro.IdNumber AS ConductorNroDocId, 
IIF(dro.IdCountry = 176, '1', 'B') AS ConductorTipoDocId
, dro.DriverName AS NombConductor, 
1 AS NroLinConductor, 
dro.LicenseNumber AS NumLicenciaCond, 
'Principal' AS TipoConductor
/*
--DATOS ADICIONALES
,'null' AS DescripcionAdicsunat, '03' AS NmrLineasAdicSunat, '1' AS NmrLineasDetalle, '01' AS TipoAdicSunat
*/
--DATOS GUIA
, CASE mt.IdColumn 
	WHEN 1 THEN 'VENTA' 
	WHEN 2 THEN 'EXPORTACION'
	WHEN 3 THEN 'TRASLADO ENTRE ESTABLECIMIENTOS DE LA MISMA EMPRESA'
	WHEN 4 THEN 'DAM PENDIENTE DE REFRENDO' 
	ELSE 'null' END AS DescTraslado, 
--IIF(@IdTransferReason = 3 OR @IdTransferReason = 4, ISNULL(anDes.direccion, ''), ISNULL(cb.[Address], '')) AS DirLlegDireccion,
--ISNULL(cb.[Address], '') AS DirLlegDireccion, 
--IIF(ISNULL(anDes.FlagDestinatario, 0) = 1, anDes.IdUbigeo, cb.IdUbige) AS DirLlegUbiGeo,
ISNULL(anDes.direccion, '') AS DirLlegDireccion, 
ISNULL(anDes.IdUbigeo, '') AS DirLlegUbiGeo,

ISNULL(anOri.direccion, '') AS DirParDireccion, 
ISNULL(anOri.IdUbigeo, '') AS DirParUbiGeo, 
--UPPER(ISNULL(ct.DeliveryAddress, '')) AS DirParDireccion, 
--IIF(
--	ISNULL(uc.GuideIssuerId, 0) = 1,
--	ISNULL(ctUC.DeliveryIdUbige, ''),
--	ISNULL(ct.DeliveryIdUbige, '')
--) AS DirParUbiGeo, 

'SUNAT_Envio' AS IdentifTraslado
, ISNULL(LEFT(mt.Valor, 2), 'null') AS MotivoTraslado, 
CONCAT(we.InputObs, ' - ', we.OutputObs) AS Observaciones, 
ve.TruckNumber AS PlacaVehicPrinc, 
ve.TruckInscription AS CertHabVehicularPrinc,
we.NetWeight AS TotalPesoTraslado, 
'KGM' AS UnmdTotalPeso

--GUIA VEHICULO SECUNDARIO
, 1 AS nroLinVehSec, ve.TrailerNumber AS placaVehicSec, 
ve.TrailerInscription AS certHabVehicularSec, 
'null' AS entEmisoraVehSec, 
'null' AS numAutorizVehSec
/*
--PROPIEDADES ADICIONALES
, 'null' AS NroLinDet, 'null' AS CodConTrib, 'null' AS ValConTrib
, 'null' AS NroLinDet, 'null' AS CodConTrib, 'null' AS ValConTrib
*/
--REFERENCIAS			
, '1' AS NroLinRef, 
'50' AS TpoDocRef, 
ISNULL(@serieDam, 'null') AS SerieRef, 
ISNULL(@correlativoDam, 'null') AS FolioRef,

--PROPIEDADES ADICIONALES
'1' AS PANroLinDet,
'7021' AS CodConTrib,
ISNULL(uc.dam, '') AS Dam

--TRAMO
, ISNULL(CONVERT(VARCHAR(10), we.OutputDate, 120), '') AS FechInicioTraslado, 
mst.IdColumn AS ModalidadTraslado
, ISNULL(ca.CarrienNumber, '') AS RUCTransport, 
'6' AS TipoRucTrans, 
ISNULL(UPPER(ca.Carrier), '') AS RazoTrans, 
ISNULL(UPPER(ca.CarrierRegNumMTC), '') AS NumRegMTC, 
'1' AS NroLinTramo

--PUERTO/AEROPUERTO
, '1' AS NroLinPuertoAerop, 
ISNULL(SUBSTRING(RTRIM(LTRIM(sp.SeaportCode)),3,3), '') AS IdPuertoAerop, 
ISNULL(UPPER(sp.SeaportName), '') AS NmbPuertoAerop, 
'1' AS TipoPuertoAerop

--GUIA CONTENEDORES
, '1' AS NroLinContenedor,
IIF(we.InputIdContainer IS NULL, ISNULL(we.OutputContainerCode, ''),  ISNULL(we.InputContainerCode, '')) AS IdContenedor, 
--CONCAT(ISNULL(we.SealCustoms, ''), '/', ISNULL(we.SealLine, ''), '/', ISNULL(we.SealSupervisor, '')) AS NumPrecinto
ISNULL(we.SealCustoms, '') AS NumPrecinto

--GUIA INDICADOR TRASLADO
--, mt.IdColumn AS NroLinIndicadorTrasl, 
, 1 AS NroLinIndicadorTrasl, 
SUBSTRING(mt.Valor,4, LEN(mt.Valor)) AS IndicadorTraslado

--DETALLES
, CONCAT(pr.DescProduct,' (',uc.PRTNUM,')') AS NmbItem
, '1' AS NroLinDet --INCREMENTA HASTA 7 TEXTO
, 1 AS NroLinea --INCREMENTA HASTA 7 NUMERICO
--LOS DETALLES DEL 2 AL 7 SE VALOR NULL EXCEPTO LOS DOS ANTERIORES
, we.NetWeight AS QtyItem
--, we.OutputWeight AS QtyItem
, IIF(@IdTransferReason = 2, 'KG', 'KGM') AS UnmdItem --SIN CAMPO EN TABLA WEIGHING
, ISNULL(pr.CodProduct, '') AS VlrCodigo

--ENCABEZADO (CAMPOS ENCABEZADO)
, cb.IdCompany AS CODI_EMPR -- Impala = 1, Trafigura = 2, Otros = 0, Chinalco = Por definir
, ISNULL(anOri.CodAnexo, '') AS CodigoLocalAnexo, 
ISNULL(anDes.CodAnexo, '') AS CodigoLocalAnexoLlegada, 
'null' AS ComuEmis
, RIGHT('00000000' + LTRIM(RTRIM(SUBSTRING(we.GuideNumber, CHARINDEX('-', we.GuideNumber)+1, LEN(we.GuideNumber)-CHARINDEX('-', we.GuideNumber)))),8) AS Correlativo
, 
UPPER(ISNULL(ubd.DPTO, '')) AS DeparEmis, 
IIF(@IdTransferReason = 3 OR @IdTransferReason = 4,
	ISNULL(anOri.direccion, ''),
	IIF(
		ISNULL(uc.GuideIssuerId, 0) = 1,
		UPPER(ISNULL(ctUC.DeliveryAddress, '')),
		UPPER(ISNULL(ct.DeliveryAddress, ''))
	)
) AS DirEmis, 
IIF(@IdTransferReason = 3 OR @IdTransferReason = 4,
	ISNULL(anDes.direccion, ''),
	UPPER(ISNULL(cb.[Address], ''))
) AS DirRecep, 
UPPER(ISNULL(coo.CountryCod, '')) AS DirRecepCodPais
, UPPER(cb.Department) AS DirRecepDepartamento,
UPPER(cb.District) AS DirRecepDistrito,
UPPER(ISNULL(cb.Province, '')) AS DirRecepProvincia,
UPPER(ISNULL(ubd.DIST, '')) AS DistriEmis
, ISNULL(CONVERT(VARCHAR(10), we.OutputDate, 120), '') AS FchEmis, 
ISNULL(CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, we.OutputDate), 108), '') AS HoraEmision,

IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	UPPER(ISNULL(ctUC.BusinessName, '')),
	UPPER(ct.BusinessName)
) AS NomComer, 

ISNULL(cod.CountryCod, '') AS PaisEmis, 
UPPER(ISNULL(ubd.PROV, '')) AS ProviEmis,

IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Ruc, ''),
	ct.Ruc
) AS RUTEmis,
IIF(ISNULL(anDes.FlagDestinatario, 0) = 1,
(SELECT TOP(1) ctDes.Ruc FROM Client ctDes WHERE ctDes.Ruc = anDes.RucAnexo AND ctDes.DeletedFlag = 0),
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Ruc, ''),
	cb.Number
)) AS RUTRecep,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	UPPER(ISNULL(ctUC.BusinessName, '')),
	UPPER(ct.BusinessName)
) AS RznSocEmis, 
IIF(ISNULL(anDes.FlagDestinatario, 0) = 1,
(SELECT TOP(1) ctDes.BusinessName FROM Client ctDes WHERE ctDes.Ruc = anDes.RucAnexo AND ctDes.DeletedFlag = 0),
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	UPPER(ISNULL(ctUC.BusinessName, '')),
	UPPER(cb.CompanyBranch)
)) AS RznSocRecep
, LTRIM(RTRIM(SUBSTRING(we.GuideNumber, 0, CHARINDEX('-', we.GuideNumber)))) AS Serie
, '09' AS TipoDTE, 
'null' AS TipoMoneda, 
'6' AS TipoRucEmis, 
'6' AS TipoRutReceptor

--EXTRAS (ENVIO PDF)
, 
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Email, ''),
	ISNULL(ct.Email, '')
) AS MailEnvi, 
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Email_CC, ''),
	ISNULL(ct.Email_CC, '')
) AS MailCopia,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Email_CCO, ''),
	ISNULL(ct.Email_CCO, '')
) AS MailCopiaOculta, 
1 AS NroLinMail

--USUARIO
,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.UserName, ''),
	ISNULL(ct.UserName, '')
) AS Usuario,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.[Password], ''),
	ISNULL(ct.[Password], '')
) AS [Password],
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.Token, ''),
	ISNULL(ct.Token, '')
) AS Token,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.URL_SendJson, ''),
	ISNULL(ct.URL_SendJson, '')
) AS URL_SendJson,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.URL_Download, ''),
	ISNULL(ct.URL_Download, '')
) AS URL_Download,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.URL_ConsultStatus, ''),
	ISNULL(ct.URL_ConsultStatus, '')
) AS URL_ConsultStatus,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.FlagDinamicToken, 0),
	ISNULL(ct.FlagDinamicToken, 0)
) AS FlagDinamicToken,
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.URL_ConsultToken, ''),
	ISNULL(ct.URL_ConsultToken, '')
) AS URL_ConsultToken,
we.QuantityBags AS NroBultos,
ISNULL(uc.GuideIssuerId, 0) AS GuideIssuerId,
ISNULL(anOri.FlagDestinatario, CAST(0 AS BIT)) AS FlagDestinatarioOri,
ISNULL(anDes.FlagDestinatario, CAST(0 AS BIT)) AS FlagDestinatarioDes
FROM Weighing we
INNER JOIN Vehicle ve ON ve.IdCompany = we.IdCompany AND ve.IdVehicle = we.IdVehicle AND ve.DeletedFlag = 0
INNER JOIN CompanyBranch cb ON cb.IdCompany = we.IdCompany AND cb.IdCompanyBranch = we.IdCompanyBranch
INNER JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
LEFT JOIN Country coo ON coo.IdCountry = cb.IdCountry
LEFT JOIN Ubige ubd ON ubd.IdUbige = ct.DeliveryIdUbige
LEFT JOIN Country cod ON cod.IdCountry = ubd.IdCountry
LEFT JOIN Carrier ca ON ca.IdCompany = we.IdCompany AND ca.IdCarrier = ve.IdCarrier AND ca.DeletedFlag = 0
LEFT JOIN WeighingCycle wecy ON wecy.IdCompany = we.IdCompany AND wecy.IdWeighingCycle = we.IdWeighingCycle
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN Client ctUC ON ctUC.IdCompany = @IdCompany AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
LEFT JOIN Seaport sp ON sp.IdSeaport = uc.OriginIdSeaport
LEFT JOIN Container con ON con.ContainerCode = we.OutputContainerCode
LEFT JOIN Driver dro ON dro.IdCompanyBranch = we.IdCompanyBranch AND dro.IdDriver = we.OutputIdDriver
LEFT JOIN Product pr ON pr.IdCompany = @IdCompany AND pr.IdCompanyBranch = we.IdCompanyBranch AND pr.CodProduct = uc.PRTNUM
LEFT JOIN MasterTable mt ON mt.IdTable = 26 AND mt.IdColumn = we.IdMotivoTraslado
LEFT JOIN MasterTable mst ON mst.IdTable = 48 AND mst.IdColumn = @IdTransferModality
LEFT JOIN Anexo anOri ON anOri.IdAnexo = uc.OrigenIdAnexo
LEFT JOIN Anexo anDes ON anDes.IdAnexo = uc.DestinoIdAnexo
WHERE we.IdCompany = @IdCompany
AND we.IdWeighing = @IdWeighing
--AND we.IdStatus = @IdStatus
AND we.IdWeighingCycle = @IdWeighingCycle
--AND IdMotivoTraslado = @IdTransferReason 
--AND IdTransferModality = @IdTransferModality

--DATOS ADICIONALES
SELECT ISNULL(uc.Buque, '') AS DescripcionAdicsunat, '02' AS NmrLineasAdicSunat, '' AS NmrLineasDetalle, '01' AS TipoAdicSunat
FROM Weighing we
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(IDOUTBOUND, ''), '04', '', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(uc.DestinationPort, ''), '06', '1', '01'
FROM Weighing we
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
--UNION ALL
--SELECT ISNULL(ct.DeliveryAddress, ''), '09', '2', '01'
--FROM Weighing we
--LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
--WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
--AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(ca.[Address], ''), '11', '3', '01'
FROM Weighing we
INNER JOIN Vehicle ve ON ve.IdCompany = we.IdCompany AND ve.IdVehicle = we.IdVehicle AND ve.DeletedFlag = 0
LEFT JOIN Carrier ca ON ca.IdCompany = we.IdCompany AND ca.IdCarrier = ve.IdCarrier AND ca.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(UPPER(mt.[Description]), 'null'), '16', '4', '01'
FROM Weighing we
LEFT JOIN MasterTable mt ON mt.IdTable = 26 AND mt.IdColumn = we.IdMotivoTraslado
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT
ISNULL(an.Serie, '') AS Serie,
'17',
'5',
'01'
FROM Weighing we
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN dbo.Anexo an ON an.IdCompany = @IdCompany AND an.IdCompanyBranch = we.IdCompanyBranch 
						AND an.IdAnexo = uc.DestinoIdAnexo AND an.DeletedFlag = 0
WHERE we.IdCompany = @IdCompany
AND we.IdWeighing = @IdWeighing 
AND we.IdStatus = @IdStatus 
AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason 
AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(CAST(ISNULL(InputContainerTareWeight, 0) + ISNULL(OutputContainerTareWeight, 0) AS VARCHAR), '')+' KGM', '18', '6', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(SealCustoms, ''), '19', '7', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(SealLine, ''), '20', '8', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(SealSupervisor, ''), '21', '9', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT CAST(OutputWeight AS VARCHAR) + ' KGM', '23', '10', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(CAST(InputWeight + ISNULL(OutputContainerTareWeight, 0) AS VARCHAR), '')+' KGM', '24', '11', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(CAST(NetWeight AS VARCHAR), '')+' KGM', '25', '12', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ISNULL(CONVERT(VARCHAR(10), con.CreatedDate, 120), ''), '26', '13', '01'
FROM Weighing we
LEFT JOIN Container con ON con.ContainerCode = IIF(we.OutputContainerCode = NULL, we.InputContainerCode, we.OutputContainerCode)
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
--UNION ALL
--SELECT ISNULL(uc.DAM, ''), '30', '14', '01'
--FROM Weighing we
--LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
--WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
--AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
SELECT
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(ctUC.[Address], ''),
	ISNULL(ct.[Address], '')
) AS [Address],
'07',
'15',
'01'
FROM Weighing we
LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN Client ctUC ON ctUC.IdCompany = 1 AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
SELECT
IIF(
	ISNULL(uc.GuideIssuerId, 0) = 1,
	ISNULL(CONVERT(VARCHAR, ctUC.DeliveryIdUbige), ''),
	ISNULL(CONVERT(VARCHAR, ct.DeliveryIdUbige), '')
) AS DeliveryIdUbige,
'08',
'16',
'01'
FROM Weighing we
LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN Client ctUC ON ctUC.IdCompany = 1 AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
SELECT
IIF(ISNULL(anDes.FlagDestinatario, 0) = 1, 
	(SELECT TOP(1) ctDes.[Address] FROM Client ctDes WHERE ctDes.Ruc = anDes.RucAnexo AND ctDes.DeletedFlag = 0),
	IIF(ISNULL(uc.GuideIssuerId, 0) = 1,
		IIF(@IdTransferReason IN (3, 4), ISNULL(ctUC.[Address], ''), ISNULL(cb.[Address], '')),
		IIF(@IdTransferReason IN (3, 4), ISNULL(ct.[Address], ''), ISNULL(cb.[Address], ''))
))AS [Address],
'09',
'17',
'01'
FROM Weighing we
INNER JOIN CompanyBranch cb ON cb.IdCompany = we.IdCompany AND cb.IdCompanyBranch = we.IdCompanyBranch AND cb.DeletedFlag = 0
LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN Client ctUC ON ctUC.IdCompany = 1 AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
LEFT JOIN Anexo anDes ON anDes.IdCompany = 1 AND anDes.IdAnexo = uc.DestinoIdAnexo AND ctUC.DeletedFlag = 0
--LEFT JOIN Client ctDes ON ctDes.IdCompanyBranch = 3 AND ctDes.Ruc = anDes.RucAnexo AND ctDes.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
--SELECT
--IIF(
--	ISNULL(uc.GuideIssuerId, 0) = 1,
--	IIF(@IdTransferReason = 3, ISNULL(CONVERT(VARCHAR, ctUC.DeliveryIdUbige), ''), ISNULL(CONVERT(VARCHAR, cb.IdUbige), '')),
--	IIF(@IdTransferReason = 3, ISNULL(CONVERT(VARCHAR, ct.DeliveryIdUbige), ''), ISNULL(CONVERT(VARCHAR, cb.IdUbige), ''))
--),
--'10',
--'18',
--'01'
--FROM Weighing we
--INNER JOIN CompanyBranch cb ON cb.IdCompany = we.IdCompany AND cb.IdCompanyBranch = we.IdCompanyBranch AND cb.DeletedFlag = 0
--LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
--LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
--LEFT JOIN Client ctUC ON ctUC.IdCompany = 1 AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
--WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
--AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

SELECT
IIF(ISNULL(anDes.FlagDestinatario, 0) = 1,
	anDes.IdUbigeo,
	IIF(ISNULL(uc.GuideIssuerId, 0) = 1,
	IIF(@IdTransferReason IN (3, 4), ISNULL(CONVERT(VARCHAR, ctUC.DeliveryIdUbige), ''), ISNULL(CONVERT(VARCHAR, cb.IdUbige), '')),
	IIF(@IdTransferReason IN (3, 4), ISNULL(CONVERT(VARCHAR, ct.DeliveryIdUbige), ''), ISNULL(CONVERT(VARCHAR, cb.IdUbige), ''))
)),
'10',
'18',
'01'
FROM Weighing we
INNER JOIN CompanyBranch cb ON cb.IdCompany = we.IdCompany AND cb.IdCompanyBranch = we.IdCompanyBranch AND cb.DeletedFlag = 0
LEFT JOIN Client ct ON ct.IdCompany = we.IdCompany AND ct.IdClient = we.IdClient AND ct.DeletedFlag = 0
LEFT JOIN UC_PICK_TO_SCALE uc ON uc.ORDNUM = we.IDOUTBOUND
LEFT JOIN Client ctUC ON ctUC.IdCompany = 1 AND ctUC.IdClient = ISNULL(uc.IssuingClientId, 0) AND ctUC.DeletedFlag = 0
LEFT JOIN Anexo anDes ON anDes.IdCompany = 1 AND anDes.IdAnexo = uc.DestinoIdAnexo AND ctUC.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
SELECT '', '27', '19', '01'
FROM Weighing we
INNER JOIN CompanyBranch cb ON cb.IdCompany = we.IdCompany AND cb.IdCompanyBranch = we.IdCompanyBranch AND cb.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality

UNION ALL
SELECT CAST(we.InputIdBascule AS varchar(3)), '101', '', '01'
FROM Weighing we
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality
UNION ALL
SELECT ba.Bascule, '102', '', '01'
FROM Weighing we
INNER JOIN Bascule ba ON ba.IdCompany = we.IdCompany AND ba.IdCompanyBranch = we.IdCompanyBranch AND ba.IdBascule = we.InputIdBascule AND ba.DeletedFlag = 0
WHERE we.IdCompany = 1 AND we.IdWeighing = @IdWeighing AND we.IdStatus = @IdStatus AND we.IdWeighingCycle = @IdWeighingCycle
AND IdMotivoTraslado = @IdTransferReason AND IdTransferModality = @IdTransferModality