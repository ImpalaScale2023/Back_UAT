ALTER TABLE dbo.Client
ALTER COLUMN Token VARCHAR(1500)

GO

ALTER PROCEDURE [dbo].[Client_List]
@IdCompany INT, 
@IdCompanyBranch INT,
@IdStatus INT,
@TimeZone INT,
@Search VARCHAR(200) = '',
@PageIndex INT,
@PageSize INT
AS
SET NOCOUNT ON
DECLARE @TotalElements INT
DECLARE @Base AS TABLE
(
	IdFila INT IDENTITY PRIMARY KEY,
	IdCompany INT,
	IdClient INT,
	ClientNumber VARCHAR(20),
	BusinessName VARCHAR(100),
	Ruc VARCHAR(32), 
	IdTurn INT,
	[Address] VARCHAR(100),
	DeliveryAddress VARCHAR(100),
	IdTypePerson VARCHAR(1),
	FlagBilingAddress BIT,
	IdStatus INT, 
	[Status] VARCHAR(20),
	DeletedFlag BIT,
	CreatedIdCompany INT,
	CreatedCompany VARCHAR(100),
	CreatedIdUser INT,
	CreatedUser VARCHAR(100),
	CreatedDate VARCHAR(20),
	UpdatedIdCompany INT,
	UpdatedCompany VARCHAR(100),
	UpdatedIdUser INT,
	UpdatedUser VARCHAR(100),
	UpdatedDate VARCHAR(20),
	DeliveryIdUbige VARCHAR(6),
	Email VARCHAR(50), 
	Email_CC VARCHAR(50), 
	Email_CCO VARCHAR(50), 
	UserName VARCHAR(20), 
	[Password] VARCHAR(50), 
	URL_SendJson VARCHAR(100), 
	URL_Download VARCHAR(100), 
	URL_ConsultStatus VARCHAR(100),
	URL_ConsultToken VARCHAR(100),
	FlagDinamicToken BIT,
	Token VARCHAR(1500), 
	Serie VARCHAR(5),
	Correlative INT
)
INSERT INTO @Base (IdCompany, IdClient, ClientNumber, BusinessName, Ruc, IdTurn, [Address], DeliveryAddress, IdTypePerson, 
	FlagBilingAddress, IdStatus, [Status], DeletedFlag, CreatedIdCompany, CreatedCompany, CreatedIdUser, CreatedUser,
	CreatedDate, UpdatedIdCompany, UpdatedCompany, UpdatedIdUser, UpdatedUser, UpdatedDate, 
	DeliveryIdUbige, Email, Email_CC, Email_CCO, UserName, [Password], URL_SendJson, URL_Download, URL_ConsultStatus, 
	URL_ConsultToken, FlagDinamicToken, Token, Serie, Correlative)
SELECT
co.IdCompany,
co.IdClient,
co.ClientNumber,
co.BusinessName,
co.Ruc,
co.IdTurn,
ISNULL(co.[Address], '') AS [Address],
ISNULL(DeliveryAddress, ''),
co.IdTypePerson,
co.FlagBillingAddress,
co.IdStatus,
tmai.[Description] AS [Status],
co.DeletedFlag,
co.CreatedIdCompany,
emp.CompanyName AS CreatedCompany,
co.CreatedIdUser,
us.UserLogin AS CreatedUser,
CONVERT(VARCHAR(10), co.CreatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, co.CreatedDate), 108) AS CreatedDate,
ISNULL(co.UpdatedIdCompany, '') AS UpdatedIdCompany,
ISNULL(emp2.CompanyName, '') AS UpdatedCompany,
ISNULL(co.UpdatedIdUser, '') AS UpdatedIdUser,
ISNULL(us2.UserLogin, '') AS UpdatedUser,
ISNULL(CONVERT(VARCHAR(10), co.UpdatedDate, 120) + ' ' + CONVERT(VARCHAR(8), DATEADD(MINUTE, @TimeZone, co.UpdatedDate), 108), ' ') AS UpdatedDate,
ISNULL(co.DeliveryIdUbige, '') AS DeliveryIdUbige, 
ISNULL(co.Email, '') AS Email, 
ISNULL(co.Email_CC, '') AS Email_CC, 
ISNULL(co.Email_CCO, '') AS Email_CCO, 
ISNULL(co.UserName, '') AS UserName, 
ISNULL(co.[Password], '') AS [Password], 
ISNULL(co.URL_SendJson, '') AS URL_SendJson, 
ISNULL(co.URL_Download, '') AS URL_Download, 
ISNULL(co.URL_ConsultStatus, '') AS URL_ConsultStatus,
ISNULL(co.URL_ConsultToken, '') AS URL_ConsultToken,
ISNULL(co.FlagDinamicToken, CAST(0 AS BIT)) AS FlagDinamicToken,
ISNULL(co.Token, '') AS Token, 
ISNULL(co.Serie, '') AS Serie,
ISNULL(co.Correlative, '') AS Correlative
FROM Client co
INNER JOIN MasterTable tmai ON tmai.IdTable = 1 AND tmai.IdColumn = co.IdStatus AND tmai.IdColumn > 0
INNER JOIN Company emp ON emp.IdCompany = co.CreatedIdCompany
LEFT JOIN Company emp2 ON emp2.IdCompany = co.UpdatedIdCompany
INNER JOIN [User] us ON us.IdUser = co.CreatedIdUser
LEFT JOIN [User] us2 ON us2.IdUser = co.UpdatedIdUser
WHERE (co.IdCompany = @IdCompany OR @IdCompany = 0) 
AND co.IdClient > 0 
AND (@IdCompanyBranch = 0 OR co.IdCompanyBranch = @IdCompanyBranch)
AND co.DeletedFlag = 0
AND (co.IdStatus = @IdStatus OR @IdStatus = 0)
AND (
        co.ClientNumber LIKE '%' + @Search + '%' OR co.ruc LIKE '%' + @Search + '%' OR co.businessName LIKE '%' + @Search + '%'
        OR co.[Address] LIKE '%' + @Search + '%' OR co.deliveryAddress LIKE '%' + @Search + '%' 
    )

SELECT @TotalElements = COUNT(1) FROM @Base
SET NOCOUNT OFF
SELECT 
IdCompany,
IdClient,
ClientNumber,
BusinessName,
Ruc,
IdTurn,
[Address],
DeliveryAddress,
IdTypePerson,
FlagBilingAddress,
IdStatus, 
[Status],
CreatedCompany, 
CreatedUser, 
CreatedDate, 
UpdatedCompany, 
UpdatedUser, 
UpdatedDate,
DeliveryIdUbige, 
Email, 
Email_CC, 
Email_CCO, 
UserName, 
[Password], 
URL_SendJson, 
URL_Download,
URL_ConsultStatus,
URL_ConsultToken,
FlagDinamicToken,
Token,
Serie,
Correlative,
@TotalElements AS TotalElements
FROM @Base
WHERE DeletedFlag = 0
ORDER BY BusinessName ASC
OFFSET @PageSize * (@PageIndex - 1) ROWS
FETCH NEXT @PageSize ROWS ONLY

GO
ALTER PROCEDURE [dbo].[Client_InsertUpdate]
@IdCompany INT,
@IdCompanyBranch INT,
@IdClient INT,
@ClientNumber VARCHAR(20),
@BusinessName VARCHAR(100),
@Ruc VARCHAR(32),
@IdTurn INT,
@Address VARCHAR(100),
@DeliveryAddress VARCHAR(100),
@IdTypePerson VARCHAR(1),
@FlagBilingAddress BIT,
@DeliveryIdUbige VARCHAR(6),
@Email VARCHAR(50), 
@Email_CC VARCHAR(50), 
@Email_CCO VARCHAR(50), 
@UserName VARCHAR(20), 
@Password VARCHAR(50), 
@URL_SendJson VARCHAR(100), 
@URL_Download VARCHAR(100), 
@URL_ConsultStatus VARCHAR(100),
@URL_ConsultToken VARCHAR(100),
@FlagDinamicToken BIT,
@Token VARCHAR(1500),
@Serie VARCHAR(5),
@Correlative INT,
@IdStatus INT,
@IdCompanyAud INT,
@IdUserAud INT,
@Error varchar(MAX) OUTPUT
AS

BEGIN TRAN
BEGIN TRY
	SET @Error = ''
	IF @IdClient = 0
	BEGIN
		SET NOCOUNT ON
		SELECT @IdClient = ISNULL(MAX(IdClient), 0) + 1 FROM Client
		SET NOCOUNT OFF
	
		INSERT INTO Client(IdCompany, IdCompanyBranch, IdClient, ClientNumber, BusinessName, Ruc, IdTurn, [Address],
		DeliveryAddress, IdTypePerson, FlagBillingAddress, IdStatus, DeletedFlag, CreatedIdCompany, CreatedIdUser, CreatedDate,
		DeliveryIdUbige, Email, Email_CC, Email_CCO, UserName, [Password], URL_SendJson, URL_download, URL_ConsultStatus,
		URL_ConsultToken, FlagDinamicToken, Token, Serie, Correlative)
		VALUES (@IdCompany, @IdCompanyBranch, @IdClient, @ClientNumber, @BusinessName, @Ruc, @IdTurn, @Address, @DeliveryAddress,
		@IdTypePerson, @FlagBilingAddress, @IdStatus, 0, @IdCompanyAud, @IdUserAud, dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
		@DeliveryIdUbige, @Email, @Email_CC, @Email_CCO, @UserName, @Password, @URL_SendJson, @URL_Download, @URL_ConsultStatus,
		@URL_ConsultToken, @FlagDinamicToken, @Token, @Serie, @Correlative)
	END
	ELSE
	BEGIN
		UPDATE Client
		SET 
		IdCompany = @IdCompany,
		IdCompanyBranch = @IdCompanyBranch,
		ClientNumber = @ClientNumber,
		BusinessName = @BusinessName,
		Ruc = @Ruc,
		IdTurn = @IdTurn,
		[Address] = @Address,
		DeliveryAddress = @DeliveryAddress,
		IdTypePerson = @IdTypePerson,
		FlagBillingAddress = @FlagBilingAddress,
		IdStatus = @IdStatus,
		DeletedFlag = 0,
		UpdatedIdCompany = @IdCompanyAud,	
		UpdatedIdUser = @IdUserAud,
		UpdatedDate = dbo.FechaUTC(@IdCompany, @IdCompanyBranch),
		DeliveryIdUbige = @DeliveryIdUbige, 
		Email = @Email, 
		Email_CC = @Email_CC, 
		Email_CCO = @Email_CCO, 
		UserName = @UserName, 
		[Password] = @Password, 
		URL_SendJson = @URL_SendJson, 
		URL_Download = @URL_Download,
		URL_ConsultStatus = @URL_ConsultStatus,
		URL_ConsultToken = @URL_ConsultToken,
		FlagDinamicToken = @FlagDinamicToken,
		Token = @Token,
		Serie = @Serie,
		Correlative = @Correlative
		WHERE IdClient = @IdClient
	END
	IF (SELECT COUNT(*) FROM Client WHERE IdCompany = @IdCompany 
										AND IdCompanyBranch = @IdCompanyBranch 
										AND ClientNumber = @ClientNumber 
										AND IdStatus = 1 
										AND DeletedFlag = 0) > 1
    BEGIN
        ROLLBACK TRAN
        SET @Error = '#VALID!' + 'The IdNumber already exists'
    END
	ELSE IF (SELECT COUNT(*) FROM Client WHERE IdCompany = @IdCompany 
										AND IdCompanyBranch = @IdCompanyBranch 
										AND Ruc = @Ruc 
										AND IdStatus = 1 
										AND DeletedFlag = 0) > 1
    BEGIN
        ROLLBACK TRAN
        SET @Error = '#VALID!' + 'The Ruc already exists'
    END
	ELSE IF (@Serie <> '' AND (SELECT COUNT(*) FROM Client WHERE IdCompany = @IdCompany 
										AND IdCompanyBranch = @IdCompanyBranch 
										AND Serie = @Serie
										AND IdStatus = 1 
										AND DeletedFlag = 0) > 1)
    BEGIN
        ROLLBACK TRAN
        SET @Error = '#VALID!' + 'The Serie already exists'
    END
    ELSE
    BEGIN
        COMMIT TRAN
    END

END TRY
BEGIN CATCH
    ROLLBACK TRAN
    SET @Error = CONCAT('L�nea N�', ERROR_LINE(), ': ', ERROR_MESSAGE())
END CATCH